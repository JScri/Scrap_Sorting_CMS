%% optimise_bayesian.m
% Bayesian optimisation with axis ratio parameters
% Similar to Optuna's TPE algorithm but using MATLAB's bayesopt and EI+

% Manually reconfigure this script to optimise parameters for either dpid_
%   or "non-dpid" models by changing prefix before init and sim calls
% Lines 17, 150, 237 and 238 are where such prefix changes would occur

% Group 0 - 49329 CMS
% Author: Jason T Stewart

%% Initialise system once
fprintf('========================================\n');
fprintf('BAYESIAN OPTIMISATION WITH AXIS RATIOS\n');
fprintf('========================================\n');

init_robotic_sorting; % change to dpid_init_robotic_sorting when optimising the DPID model's parameters

%% Define optimisation variables with ratios
% Base parameters
vars = [
    optimizableVariable('damping_x', [40, 150], 'Type', 'real');
    optimizableVariable('Kp_x', [50, 400], 'Type', 'real');
    optimizableVariable('Ki_x', [50, 600], 'Type', 'real');
    optimizableVariable('Kd_x', [2, 25], 'Type', 'real');
    
    % Axis ratios (Y relative to X)
    optimizableVariable('damping_y_ratio', [0.4, 0.8], 'Type', 'real');
    optimizableVariable('Kp_y_ratio', [0.8, 1.2], 'Type', 'real');
    optimizableVariable('Ki_y_ratio', [0.8, 1.2], 'Type', 'real');
    optimizableVariable('Kd_y_ratio', [0.8, 1.2], 'Type', 'real');
    
    % Axis ratios (Z relative to X)
    optimizableVariable('damping_z_ratio', [0.2, 0.6], 'Type', 'real');
    optimizableVariable('Kp_z_ratio', [1.0, 1.6], 'Type', 'real');
    optimizableVariable('Ki_z_ratio', [1.2, 2.0], 'Type', 'real');
    optimizableVariable('Kd_z_ratio', [1.2, 2.0], 'Type', 'real');
];

%% Objective function
objective_fun = @(params) evaluate_parameters(params);

%% Bayesian optimisation settings
options = struct();
options.MaxObjectiveEvaluations = 50;  % Like Optuna's n_trials
options.IsObjectiveDeterministic = false;  % Allows for simulation variance
options.AcquisitionFunctionName = 'expected-improvement-plus';  % Similar to TPE - inspiration from my 49275 NN&FL project ;)
options.UseParallel = false;  % Set to true if you have Parallel Computing Toolbox - report's analysis was done on an optimisation that did not use this
options.PlotFcn = {@plotObjectiveModel, @plotMinObjective};
options.OutputFcn = @save_iteration_results;
options.Verbose = 1;

% For reproducibility
rng(42);

%% Run optimisation
fprintf('\nStarting Bayesian optimisation...\n');
fprintf('Max iterations: %d\n', options.MaxObjectiveEvaluations);
fprintf('Mode: FULL 64-dish runs (300s each)\n');
fprintf('Estimated time: ~%.1f hours\n\n', options.MaxObjectiveEvaluations * 5.0 / 60);

results = bayesopt(objective_fun, vars, ...
    'MaxObjectiveEvaluations', options.MaxObjectiveEvaluations, ...
    'IsObjectiveDeterministic', options.IsObjectiveDeterministic, ...
    'AcquisitionFunctionName', options.AcquisitionFunctionName, ...
    'UseParallel', options.UseParallel, ...
    'PlotFcn', options.PlotFcn, ...
    'OutputFcn', options.OutputFcn, ...
    'Verbose', options.Verbose);

%% Extract best parameters
best_params = results.XAtMinObjective;

fprintf('\n========================================\n');
fprintf('OPTIMISATION COMPLETE\n');
fprintf('========================================\n\n');

fprintf('OPTIMAL BASE PARAMETERS:\n');
fprintf('  Damping X: %.1f N·s/m\n', best_params.damping_x);
fprintf('  Kp X: %.1f\n', best_params.Kp_x);
fprintf('  Ki X: %.1f\n', best_params.Ki_x);
fprintf('  Kd X: %.1f\n\n', best_params.Kd_x);

fprintf('OPTIMAL Y-AXIS RATIOS:\n');
fprintf('  Damping Y ratio: %.3f (Y = %.1f)\n', best_params.damping_y_ratio, ...
    best_params.damping_x * best_params.damping_y_ratio);
fprintf('  Kp Y ratio: %.3f (Y = %.1f)\n', best_params.Kp_y_ratio, ...
    best_params.Kp_x * best_params.Kp_y_ratio);
fprintf('  Ki Y ratio: %.3f (Y = %.1f)\n', best_params.Ki_y_ratio, ...
    best_params.Ki_x * best_params.Ki_y_ratio);
fprintf('  Kd Y ratio: %.3f (Y = %.1f)\n\n', best_params.Kd_y_ratio, ...
    best_params.Kd_x * best_params.Kd_y_ratio);

fprintf('OPTIMAL Z-AXIS RATIOS:\n');
fprintf('  Damping Z ratio: %.3f (Z = %.1f)\n', best_params.damping_z_ratio, ...
    best_params.damping_x * best_params.damping_z_ratio);
fprintf('  Kp Z ratio: %.3f (Z = %.1f)\n', best_params.Kp_z_ratio, ...
    best_params.Kp_x * best_params.Kp_z_ratio);
fprintf('  Ki Z ratio: %.3f (Z = %.1f)\n', best_params.Ki_z_ratio, ...
    best_params.Ki_x * best_params.Ki_z_ratio);
fprintf('  Kd Z ratio: %.3f (Z = %.1f)\n\n', best_params.Kd_z_ratio, ...
    best_params.Kd_x * best_params.Kd_z_ratio);

fprintf('PERFORMANCE:\n');
fprintf('  Best Score: %.2f\n', results.MinObjective);
fprintf('  Total Evaluations: %d\n', results.NumObjectiveEvaluations);

%% Save results
optimal_params_bayesian = struct();
optimal_params_bayesian.damping_x = best_params.damping_x;
optimal_params_bayesian.damping_y = best_params.damping_x * best_params.damping_y_ratio;
optimal_params_bayesian.damping_z = best_params.damping_x * best_params.damping_z_ratio;

optimal_params_bayesian.Kp_x = best_params.Kp_x;
optimal_params_bayesian.Kp_y = best_params.Kp_x * best_params.Kp_y_ratio;
optimal_params_bayesian.Kp_z = best_params.Kp_x * best_params.Kp_z_ratio;

optimal_params_bayesian.Ki_x = best_params.Ki_x;
optimal_params_bayesian.Ki_y = best_params.Ki_x * best_params.Ki_y_ratio;
optimal_params_bayesian.Ki_z = best_params.Ki_x * best_params.Ki_z_ratio;

optimal_params_bayesian.Kd_x = best_params.Kd_x;
optimal_params_bayesian.Kd_y = best_params.Kd_x * best_params.Kd_y_ratio;
optimal_params_bayesian.Kd_z = best_params.Kd_x * best_params.Kd_z_ratio;

optimal_params_bayesian.ratios = struct(...
    'damping_y', best_params.damping_y_ratio, ...
    'damping_z', best_params.damping_z_ratio, ...
    'Kp_y', best_params.Kp_y_ratio, ...
    'Kp_z', best_params.Kp_z_ratio, ...
    'Ki_y', best_params.Ki_y_ratio, ...
    'Ki_z', best_params.Ki_z_ratio, ...
    'Kd_y', best_params.Kd_y_ratio, ...
    'Kd_z', best_params.Kd_z_ratio);

save('bayesian_optimisation_results.mat', 'optimal_params_bayesian', 'results');

fprintf('\nResults saved to: bayesian_optimisation_results.mat\n');
fprintf('========================================\n\n');

fprintf('To apply these parameters:\n');
fprintf('  test_damping_x = %.1f; test_damping_y = %.1f; test_damping_z = %.1f;\n', ...
    optimal_params_bayesian.damping_x, optimal_params_bayesian.damping_y, optimal_params_bayesian.damping_z);
fprintf('  test_Kp_x = %.1f; test_Kp_y = %.1f; test_Kp_z = %.1f;\n', ...
    optimal_params_bayesian.Kp_x, optimal_params_bayesian.Kp_y, optimal_params_bayesian.Kp_z);
fprintf('  test_Ki_x = %.1f; test_Ki_y = %.1f; test_Ki_z = %.1f;\n', ...
    optimal_params_bayesian.Ki_x, optimal_params_bayesian.Ki_y, optimal_params_bayesian.Ki_z);
fprintf('  test_Kd_x = %.1f; test_Kd_y = %.1f; test_Kd_z = %.1f;\n', ...
    optimal_params_bayesian.Kd_x, optimal_params_bayesian.Kd_y, optimal_params_bayesian.Kd_z);
fprintf('  init_robotic_sorting;\n\n'); % change prefix to and from "dpid_" for optimising between models

%% ========== HELPER FUNCTIONS ==========

function score = evaluate_parameters(params)
    % Objective function for Bayesian optimisation
    
    % Calculate derived parameters using ratios
    damping_x = params.damping_x;
    damping_y = params.damping_x * params.damping_y_ratio;
    damping_z = params.damping_x * params.damping_z_ratio;
    
    Kp_x = params.Kp_x;
    Kp_y = params.Kp_x * params.Kp_y_ratio;
    Kp_z = params.Kp_x * params.Kp_z_ratio;
    
    Ki_x = params.Ki_x;
    Ki_y = params.Ki_x * params.Ki_y_ratio;
    Ki_z = params.Ki_x * params.Ki_z_ratio;
    
    Kd_x = params.Kd_x;
    Kd_y = params.Kd_x * params.Kd_y_ratio;
    Kd_z = params.Kd_x * params.Kd_z_ratio;
    
    % Update workspace variables
    assignin('base', 'test_damping_x', damping_x);
    assignin('base', 'test_damping_y', damping_y);
    assignin('base', 'test_damping_z', damping_z);
    
    assignin('base', 'test_Kp_x', Kp_x);
    assignin('base', 'test_Kp_y', Kp_y);
    assignin('base', 'test_Kp_z', Kp_z);
    
    assignin('base', 'test_Ki_x', Ki_x);
    assignin('base', 'test_Ki_y', Ki_y);
    assignin('base', 'test_Ki_z', Ki_z);
    
    assignin('base', 'test_Kd_x', Kd_x);
    assignin('base', 'test_Kd_y', Kd_y);
    assignin('base', 'test_Kd_z', Kd_z);
    
    % Update A matrix
    mass_eff_x = 10;
    mass_eff_y = 5;
    mass_eff_z = 2;
    
    A_full = [0   1   0   0   0   0;
              0  -damping_x/mass_eff_x  0   0   0   0;
              0   0   0   1   0   0;
              0   0   0  -damping_y/mass_eff_y  0   0;
              0   0   0   0   0   1;
              0   0   0   0   0  -damping_z/mass_eff_z];
    
    assignin('base', 'A_full', A_full);
    
    % Update PID structs
    pid_x.Kp = Kp_x;
    pid_x.Ki = Ki_x;
    pid_x.Kd = Kd_x;
    pid_x.filter_coeff = 100;
    
    pid_y.Kp = Kp_y;
    pid_y.Ki = Ki_y;
    pid_y.Kd = Kd_y;
    pid_y.filter_coeff = 100;
    
    pid_z.Kp = Kp_z;
    pid_z.Ki = Ki_z;
    pid_z.Kd = Kd_z;
    pid_z.filter_coeff = 100;
    
    assignin('base', 'pid', struct('x', pid_x, 'y', pid_y, 'z', pid_z));
    
    % Update robot struct
    robot = evalin('base', 'robot');
    robot.damping.x = damping_x;
    robot.damping.y = damping_y;
    robot.damping.z = damping_z;
    assignin('base', 'robot', robot);
    
    % FULL RUN MODE - 64 dishes, 300 seconds
    assignin('base', 'test_mode', 0);
    assignin('base', 'max_dishes_test', 64);
    
    sim_timeout = 300;
    
    try
        set_param('robotic_sorting_system', 'SimulationCommand', 'update'); % change prefix to and from "dpid_" before sim call to optimise between models
        simOut = sim('robotic_sorting_system', 'StopTime', num2str(sim_timeout)); % change prefix to and from "dpid_" before sim call to optimise between models
        
        mean_error = extract_from_simout(simOut, 'mean_error', 1000);
        success_rate = extract_from_simout(simOut, 'success_rate', 0);
        
        % Extract final dish_idx - MUST get final value
        final_dish_idx = extract_from_simout(simOut, 'dish_idx', -999);
        
        % If extraction failed, this is a fatal error
        if final_dish_idx == -999
            fprintf('  ERROR: Could not extract dish_idx from simulation\n'); % conditional became useful in debugging and stayed
            fprintf('  Make sure To Workspace block is connected and saving dish_idx\n');
            score = 10000;  % Severe penalty
            mean_error = 1000;
            success_rate = 0;
            completion_penalty = 10000;
        else
            % Calculate penalty based on actual completion
            % Note: dish_idx = 65 means 64 dishes completed (it's the NEXT dish index) 
            expected_dishes = evalin('base', 'max_dishes_test');
            dishes_completed = final_dish_idx - 1;
            
            if dishes_completed >= expected_dishes
                completion_penalty = 0;
            else
                completion_penalty = (expected_dishes - dishes_completed) * 100;
                fprintf('  [Only completed %d/%d dishes (dish_idx=%d)]\n', ...
                    dishes_completed, expected_dishes, final_dish_idx);
            end
        end
        
        % Combined score
        if completion_penalty > 0
            score = 5000 + completion_penalty;
        elseif success_rate < 50
            score = 2000 + mean_error;
        else
            score = mean_error + (100 - success_rate) * 3;
        end
        
    catch ME
        fprintf('  FAILED: %s\n', ME.message);
        score = 10000;  % Severe penalty for failures
    end
    
    % Reset test mode
    assignin('base', 'test_mode', 0);
    
    % Log this iteration with detailed metrics
    if completion_penalty > 0
        status_str = sprintf('[INCOMPLETE: %d penalty]', completion_penalty);
    elseif success_rate < 50
        status_str = '[LOW SUCCESS]';
    else
        status_str = '[OK]';
    end
    
    fprintf('Eval: D=%.1f(%.2f,%.2f) Kp=%.1f(%.2f,%.2f) Ki=%.1f(%.2f,%.2f) Kd=%.1f(%.2f,%.2f)\n', ...
        damping_x, params.damping_y_ratio, params.damping_z_ratio, ...
        Kp_x, params.Kp_y_ratio, params.Kp_z_ratio, ...
        Ki_x, params.Ki_y_ratio, params.Ki_z_ratio, ...
        Kd_x, params.Kd_y_ratio, params.Kd_z_ratio);
    fprintf('      → Error=%.1fmm, Success=%.1f%%, Score=%.1f %s\n', ...
        mean_error, success_rate, score, status_str);
end

function stop = save_iteration_results(results, state)
    % OutputFcn to save intermediate results
    stop = false;
    
    if strcmp(state, 'iteration')
        % Save after each iteration
        save('bayesian_optimisation_checkpoint.mat', 'results');
    end
end

function value = extract_from_simout(simOut, signal_name, default_value)
    try
        if isprop(simOut, signal_name)
            data = simOut.(signal_name);
            value = process_signal_data(data, signal_name, default_value);
            return;
        end
        
        if isprop(simOut, 'logsout')
            signal = simOut.logsout.getElement(signal_name);
            if ~isempty(signal)
                data = signal.Values;
                value = process_signal_data(data, signal_name, default_value);
                return;
            end
        end
        
        value = default_value;
    catch
        value = default_value;
    end
end

function value = process_signal_data(data, signal_name, default_value)
    try
        if isa(data, 'timeseries')
            values = data.Data;
        elseif isstruct(data) && isfield(data, 'Data')
            values = data.Data;
        elseif isnumeric(data)
            values = data;
        else
            value = default_value;
            return;
        end
        
        if ~isempty(values) && length(values) > 1
            if strcmp(signal_name, 'mean_error')
                % For mean_error, average the last 25% (steady state)
                steady_idx = max(1, round(0.75*length(values))):length(values);
                value = mean(values(steady_idx));
            else
                % For everything else (dish_idx, success_rate), use FINAL value
                value = values(end);
            end
        elseif ~isempty(values)
            value = values(end);  % Single value case
        else
            value = default_value;
        end
    catch
        value = default_value;
    end
end