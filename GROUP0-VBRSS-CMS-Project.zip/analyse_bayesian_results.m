%% analyse_bayesian_results.m
% Analyse and visualise Bayesian optimisation results
% Group 0 - 49329 CMS
% Author: Jason T Stewart

if ~exist('bayesian_optimisation_results.mat', 'file')
    error('No results found. Run optimise_bayesian.m first.');
end

load('bayesian_optimisation_results.mat', 'optimal_params_bayesian', 'results');

fprintf('========================================\n');
fprintf('BAYESIAN OPTIMISATION ANALYSIS\n');
fprintf('========================================\n\n');

%% Basic Statistics
fprintf('OPTIMISATION SUMMARY:\n');
fprintf('  Total evaluations: %d\n', results.NumObjectiveEvaluations);
fprintf('  Best score: %.2f\n', results.MinObjective);
fprintf('  Best found at iteration: %d\n', results.IndexOfMinimumTrace(end));
fprintf('\n');

%% Parameter Analysis
best_params = results.XAtMinObjective;

fprintf('OPTIMAL PARAMETERS:\n');
fprintf('----------------------------------------\n');
fprintf('Base X-axis:\n');
fprintf('  Damping: %.2f N·s/m\n', best_params.damping_x);
fprintf('  Kp: %.2f\n', best_params.Kp_x);
fprintf('  Ki: %.2f\n', best_params.Ki_x);
fprintf('  Kd: %.2f\n\n', best_params.Kd_x);

fprintf('Y-axis (ratios):\n');
fprintf('  Damping: %.3f × X = %.2f\n', best_params.damping_y_ratio, ...
    best_params.damping_x * best_params.damping_y_ratio);
fprintf('  Kp: %.3f × X = %.2f\n', best_params.Kp_y_ratio, ...
    best_params.Kp_x * best_params.Kp_y_ratio);
fprintf('  Ki: %.3f × X = %.2f\n', best_params.Ki_y_ratio, ...
    best_params.Ki_x * best_params.Ki_y_ratio);
fprintf('  Kd: %.3f × X = %.2f\n\n', best_params.Kd_y_ratio, ...
    best_params.Kd_x * best_params.Kd_y_ratio);

fprintf('Z-axis (ratios):\n');
fprintf('  Damping: %.3f × X = %.2f\n', best_params.damping_z_ratio, ...
    best_params.damping_x * best_params.damping_z_ratio);
fprintf('  Kp: %.3f × X = %.2f\n', best_params.Kp_z_ratio, ...
    best_params.Kp_x * best_params.Kp_z_ratio);
fprintf('  Ki: %.3f × X = %.2f\n', best_params.Ki_z_ratio, ...
    best_params.Ki_x * best_params.Ki_z_ratio);
fprintf('  Kd: %.3f × X = %.2f\n\n', best_params.Kd_z_ratio, ...
    best_params.Kd_x * best_params.Kd_z_ratio);

%% Convergence Analysis
fprintf('CONVERGENCE:\n');
fprintf('----------------------------------------\n');
iterations = 1:results.NumObjectiveEvaluations;

% Get the minimum trace (best objective found so far at each iteration)
min_trace = zeros(results.NumObjectiveEvaluations, 1);
for i = 1:results.NumObjectiveEvaluations
    min_trace(i) = min(results.ObjectiveTrace(1:i));
end

% Check convergence
window_size = 10;
if results.NumObjectiveEvaluations > window_size
    recent_improvement = min_trace(end-window_size+1:end);
    improvement_rate = (recent_improvement(1) - recent_improvement(end)) / window_size;
    
    if improvement_rate < 0.1
        fprintf('Status: CONVERGED\n');
        fprintf('  Minimal improvement in last %d iterations\n', window_size);
    else
        fprintf('Status: STILL IMPROVING\n');
        fprintf('  Consider running more iterations\n');
    end
    fprintf('  Improvement rate: %.3f per iteration\n\n', improvement_rate);
end

%% Parameter Importance Analysis
fprintf('PARAMETER SENSITIVITY:\n');
fprintf('----------------------------------------\n');

% Extract all evaluated points
all_points = results.XTrace;
all_objectives = results.ObjectiveTrace;

% Calculate correlation of each parameter with objective
param_names = all_points.Properties.VariableNames;
correlations = zeros(length(param_names), 1);

for i = 1:length(param_names)
    param_values = table2array(all_points(:, i));
    correlations(i) = abs(corr(param_values, all_objectives));
end

[sorted_corr, sorted_idx] = sort(correlations, 'descend');

fprintf('Most important parameters (by correlation with score):\n');
for i = 1:min(5, length(param_names))
    fprintf('%d. %s: %.3f\n', i, param_names{sorted_idx(i)}, sorted_corr(i));
end
fprintf('\n');

%% Visualisation
figure('Name', 'Bayesian Optimisation Analysis', 'Position', [100, 100, 1400, 800]);

% Subplot 1: Convergence plot
subplot(2,3,1);
plot(iterations, results.ObjectiveTrace, 'b.', 'MarkerSize', 8);
hold on;
plot(iterations, results.MinObjective, 'r-', 'LineWidth', 2);
xlabel('Iteration');
ylabel('Objective Value (Score)');
title('Convergence History');
legend('Evaluations', 'Best So Far', 'Location', 'best');
grid on;

% Subplot 2: Parameter importance
subplot(2,3,2);
barh(sorted_corr(1:min(8, length(param_names))));
set(gca, 'YTickLabel', param_names(sorted_idx(1:min(8, length(param_names)))));
xlabel('|Correlation| with Objective');
title('Parameter Importance');
grid on;

% Subplot 3: Base parameter values over time
subplot(2,3,3);
plot(iterations, all_points.damping_x, '.-');
hold on;
plot(iterations, all_points.Kp_x, '.-');
plot(iterations, all_points.Ki_x, '.-');
plot(iterations, all_points.Kd_x, '.-');
xlabel('Iteration');
ylabel('Parameter Value');
title('Base Parameter Evolution');
legend('Damping X', 'Kp X', 'Ki X', 'Kd X', 'Location', 'best');
grid on;

% Subplot 4: Y-axis ratios over time
subplot(2,3,4);
plot(iterations, all_points.damping_y_ratio, '.-');
hold on;
plot(iterations, all_points.Kp_y_ratio, '.-');
plot(iterations, all_points.Ki_y_ratio, '.-');
plot(iterations, all_points.Kd_y_ratio, '.-');
xlabel('Iteration');
ylabel('Ratio Value');
title('Y-axis Ratio Evolution');
legend('Damping', 'Kp', 'Ki', 'Kd', 'Location', 'best');
grid on;

% Subplot 5: Z-axis ratios over time
subplot(2,3,5);
plot(iterations, all_points.damping_z_ratio, '.-');
hold on;
plot(iterations, all_points.Kp_z_ratio, '.-');
plot(iterations, all_points.Ki_z_ratio, '.-');
plot(iterations, all_points.Kd_z_ratio, '.-');
xlabel('Iteration');
ylabel('Ratio Value');
title('Z-axis Ratio Evolution');
legend('Damping', 'Kp', 'Ki', 'Kd', 'Location', 'best');
grid on;

% Subplot 6: Acquisition function behavior
subplot(2,3,6);
if isfield(results, 'NextPoint')
    % Show exploration vs exploitation trade-off
    plot(iterations(1:end-1), diff(results.MinObjective), 'o-');
    xlabel('Iteration');
    ylabel('Improvement per Iteration');
    title('Optimisation Progress');
    grid on;
else
    text(0.5, 0.5, 'Acquisition function data not available', ...
        'HorizontalAlignment', 'center', 'Units', 'normalized');
end

%% Comparison with initial parameters
fprintf('COMPARISON WITH INITIAL SYSTEM:\n');
fprintf('----------------------------------------\n');
fprintf('Initial (from docs):\n');
fprintf('  Damping: X=50, Y=30, Z=20\n');
fprintf('  Kp: X=200, Y=200, Z=300\n');
fprintf('  Ki: X=20, Y=20, Z=30\n');
fprintf('  Kd: X=10, Y=10, Z=15\n\n');

fprintf('Optimised:\n');
fprintf('  Damping: X=%.1f, Y=%.1f, Z=%.1f\n', ...
    optimal_params_bayesian.damping_x, ...
    optimal_params_bayesian.damping_y, ...
    optimal_params_bayesian.damping_z);
fprintf('  Kp: X=%.1f, Y=%.1f, Z=%.1f\n', ...
    optimal_params_bayesian.Kp_x, ...
    optimal_params_bayesian.Kp_y, ...
    optimal_params_bayesian.Kp_z);
fprintf('  Ki: X=%.1f, Y=%.1f, Z=%.1f\n', ...
    optimal_params_bayesian.Ki_x, ...
    optimal_params_bayesian.Ki_y, ...
    optimal_params_bayesian.Ki_z);
fprintf('  Kd: X=%.1f, Y=%.1f, Z=%.1f\n\n', ...
    optimal_params_bayesian.Kd_x, ...
    optimal_params_bayesian.Kd_y, ...
    optimal_params_bayesian.Kd_z);

%% Recommendations
fprintf('RECOMMENDATIONS:\n');
fprintf('========================================\n');

if results.NumObjectiveEvaluations < 30
    fprintf('Limited evaluations - consider running longer\n');
elseif improvement_rate > 1.0
    fprintf('Still improving rapidly - run more iterations\n');
else
    fprintf('Optimisation appears converged\n');
end

fprintf('\nNext steps:\n');
fprintf('1. Validate with full 64-dish simulation\n');
fprintf('2. Compare performance metrics with baseline\n');
fprintf('3. If satisfied, update init_robotic_sorting.m defaults\n'); % or "dpid_"
fprintf('========================================\n');