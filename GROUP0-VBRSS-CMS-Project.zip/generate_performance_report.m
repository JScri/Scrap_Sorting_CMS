%% generate_performance_report.m
% Creates performance report for robotic sorting system based on
%   compare_system_versions.m output.

% Manual input of cycle team from human read-out of cycle time needs to be
% done to ensure validity as code assumes total allotted time for sim to
% run equals cycle time, which is not the case. In this regard, s/d also
% needs to be manually corrected after report is generated.

% Load comparison data
if ~exist('system_comparison.mat', 'file')
    error('No comparison data found. Run compare_system_versions.m first.');
end

load('system_comparison.mat', 'comparison');

% Open output file
fid = fopen('Performance_Report.txt', 'w');

%% Header
fprintf(fid, '========================================================================================================\n');
fprintf(fid, '                        ROBOTIC SORTING SYSTEM PERFORMANCE REPORT\n');
fprintf(fid, '                    Group 0 - 49329 Control of Mechatronic Systems\n');
fprintf(fid, '========================================================================================================\n\n');
fprintf(fid, 'Report Generated: %s\n\n', datestr(comparison.timestamp));

%% Executive Summary
fprintf(fid, '========================================================================================================\n');
fprintf(fid, 'EXECUTIVE SUMMARY\n');
fprintf(fid, '========================================================================================================\n\n');

fprintf(fid, 'This report compares two implementations of the robotic sorting system:\n\n');
fprintf(fid, '1. DPID System (Baseline): Discrete waypoint control with grid-optimised PID parameters\n');
fprintf(fid, '2. Trajectory Smoothing System (Improved): 5th-order polynomial trajectories with\n');
fprintf(fid, '   feedforward control and Bayesian-optimised parameters\n\n');

fprintf(fid, 'KEY FINDINGS:\n');
fprintf(fid, '  • Mean tracking error reduced by %.1f%% (%.1f mm → %.1f mm)\n', ...
    comparison.improvements.mean_error_pct, comparison.dpid.mean_error, comparison.traj.mean_error);
fprintf(fid, '  • RMS error reduced by %.1f%% (%.1f mm → %.1f mm)\n', ...
    comparison.improvements.rms_error_pct, comparison.dpid.rms_error, comparison.traj.rms_error);
fprintf(fid, '  • Peak error reduced by %.1f%% (%.1f mm → %.1f mm)\n', ...
    comparison.improvements.max_error_pct, comparison.dpid.max_error, comparison.traj.max_error);
fprintf(fid, '  • Success rate: %.1f%% (DPID) vs %.1f%% (Trajectory Smoothing)\n', ...
    comparison.dpid.success_rate, comparison.traj.success_rate);
fprintf(fid, '  • Both systems achieved 100%% completion (64/64 dishes)\n\n');

%% Implementation Timeline
fprintf(fid, '========================================================================================================\n');
fprintf(fid, 'IMPLEMENTATION TIMELINE\n');
fprintf(fid, '========================================================================================================\n\n');

fprintf(fid, 'PHASE 1: BASELINE SYSTEM (DPID)\n');
fprintf(fid, '--------------------------------\n');
fprintf(fid, 'Control Architecture:\n');
fprintf(fid, '  • Discrete waypoint-based trajectory planning\n');
fprintf(fid, '  • PID feedback control on each axis\n');
fprintf(fid, '  • Step changes in target position at each waypoint\n');
fprintf(fid, '  • Position tolerance: 150 mm\n\n');

fprintf(fid, 'Parameter Optimisation:\n');
fprintf(fid, '  • Method: Multi-parameter grid search\n');
fprintf(fid, '  • Parameters optimised: Damping coefficients, Ki gains\n');
fprintf(fid, '  • Optimal damping: X=120, Y=72, Z=48 N·s/m\n');
fprintf(fid, '  • Optimal integral gains: Ki_x=300, Ki_y=300, Ki_z=450\n\n');

fprintf(fid, 'Performance Issues Identified:\n');
fprintf(fid, '  • High tracking error (~318 mm mean) during transitions\n');
fprintf(fid, '  • Step changes in position caused infinite theoretical acceleration\n');
fprintf(fid, '  • Aggressive PID response to sudden target changes\n');
fprintf(fid, '  • Mechanical stress from rapid corrections\n\n');

fprintf(fid, 'PHASE 2: TRAJECTORY SMOOTHING IMPLEMENTATION\n');
fprintf(fid, '--------------------------------------------\n');
fprintf(fid, 'Improvements Made:\n');
fprintf(fid, '  1. Generated smooth 5th-order polynomial trajectories\n');
fprintf(fid, '     - Continuous position, velocity, and acceleration\n');
fprintf(fid, '     - Zero velocity and acceleration at waypoints\n');
fprintf(fid, '     - 156 pre-computed trajectories for all robot paths\n\n');

fprintf(fid, '  2. Implemented feedforward control\n');
fprintf(fid, '     - Model-based force prediction: F_ff = Ma + Bv\n');
fprintf(fid, '     - Combined with PID feedback: F_total = F_pid + F_ff\n');
fprintf(fid, '     - Feedforward gain: 1.0 (assumes accurate model)\n\n');

fprintf(fid, '  3. Tolerance optimisation\n');
fprintf(fid, '     - Initial: 0.065 mm (too tight, 384s cycle time)\n');
fprintf(fid, '     - Optimised: 0.5 mm (266s cycle time)\n');
fprintf(fid, '     - Further increases showed diminishing returns\n');
fprintf(fid, '     - Proper optimisation of this factor would be beneficial, considering mean_error, success_rate and cycle time\n\n');

fprintf(fid, 'PHASE 3: BAYESIAN PARAMETER OPTIMISATION\n');
fprintf(fid, '-----------------------------------------\n');
fprintf(fid, 'Optimisation Strategy:\n');
fprintf(fid, '  • Algorithm: Bayesian optimisation (Expected Improvement Plus)\n');
fprintf(fid, '  • Parameters: 12 total (4 base + 8 axis ratios)\n');
fprintf(fid, '  • Evaluations: 50 trials over ~27 minutes\n');
fprintf(fid, '  • Efficiency: 10,629× faster than equivalent grid search\n\n');

fprintf(fid, 'Optimised Parameters (DPID):\n');
fprintf(fid, '  Damping:  X=%.1f, Y=%.1f, Z=%.1f N·s/m\n', ...
    comparison.dpid.params.damping_x, comparison.dpid.params.damping_y, comparison.dpid.params.damping_z);
fprintf(fid, '  Kp gains: X=%.1f, Y=%.1f, Z=%.1f\n', ...
    comparison.dpid.params.Kp_x, comparison.dpid.params.Kp_y, comparison.dpid.params.Kp_z);
fprintf(fid, '  Ki gains: X=%.1f, Y=%.1f, Z=%.1f\n', ...
    comparison.dpid.params.Ki_x, comparison.dpid.params.Ki_y, comparison.dpid.params.Ki_z);
fprintf(fid, '  Kd gains: X=%.1f, Y=%.1f, Z=%.1f\n\n', ...
    comparison.dpid.params.Kd_x, comparison.dpid.params.Kd_y, comparison.dpid.params.Kd_z);

fprintf(fid, 'Optimised Parameters (TS):\n');
fprintf(fid, '  Damping:  X=%.1f, Y=%.1f, Z=%.1f N·s/m\n', ...
    comparison.traj.params.damping_x, comparison.traj.params.damping_y, comparison.traj.params.damping_z);
fprintf(fid, '  Kp gains: X=%.1f, Y=%.1f, Z=%.1f\n', ...
    comparison.traj.params.Kp_x, comparison.traj.params.Kp_y, comparison.traj.params.Kp_z);
fprintf(fid, '  Ki gains: X=%.1f, Y=%.1f, Z=%.1f\n', ...
    comparison.traj.params.Ki_x, comparison.traj.params.Ki_y, comparison.traj.params.Ki_z);
fprintf(fid, '  Kd gains: X=%.1f, Y=%.1f, Z=%.1f\n\n', ...
    comparison.traj.params.Kd_x, comparison.traj.params.Kd_y, comparison.traj.params.Kd_z);

fprintf(fid, 'Key Findings from Optimisation:\n');
fprintf(fid, '  • Damping increased by ~25%% (150 vs 120 N·s/m)\n');
fprintf(fid, '  • Kp increased ~4× (393 vs 100)\n');
fprintf(fid, '  • Ki increased ~1.65× (495 vs 300)\n');
fprintf(fid, '  • Y/X damping ratio: 0.76 (close to assumed 0.6)\n');
fprintf(fid, '  • Z/X damping ratio: 0.45 (close to assumed 0.4)\n\n');

%% Detailed Performance Comparison
fprintf(fid, '========================================================================================================\n');
fprintf(fid, 'DETAILED PERFORMANCE COMPARISON\n');
fprintf(fid, '========================================================================================================\n\n');

fprintf(fid, 'ACCURACY METRICS:\n');
fprintf(fid, '%-30s %18s %18s %18s\n', 'Metric', 'DPID', 'Traj Smoothing', 'Improvement');
fprintf(fid, '%-30s %18s %18s %18s\n', repmat('-', 1, 30), repmat('-', 1, 18), repmat('-', 1, 18), repmat('-', 1, 18));
fprintf(fid, '%-30s %15.2f mm %15.2f mm %15.1f%%\n', 'Mean Error', comparison.dpid.mean_error, comparison.traj.mean_error, comparison.improvements.mean_error_pct);
fprintf(fid, '%-30s %15.2f mm %15.2f mm %15.1f%%\n', 'RMS Error', comparison.dpid.rms_error, comparison.traj.rms_error, comparison.improvements.rms_error_pct);
fprintf(fid, '%-30s %15.2f mm %15.2f mm %15.1f%%\n', 'Maximum Error', comparison.dpid.max_error, comparison.traj.max_error, comparison.improvements.max_error_pct);
fprintf(fid, '%-30s %15.2f mm %15.2f mm %18s\n', 'Standard Deviation', comparison.dpid.std_error, comparison.traj.std_error, '-');
fprintf(fid, '%-30s %15.2f mm %15.2f mm %18s\n', '95th Percentile Error', comparison.dpid.error_95th, comparison.traj.error_95th, '-');
fprintf(fid, '%-30s %15.2f mm %15.2f mm %18s\n\n', '99th Percentile Error', comparison.dpid.error_99th, comparison.traj.error_99th, '-');

fprintf(fid, 'OPERATIONAL METRICS:\n');
fprintf(fid, '%-30s %18s %18s %18s\n', 'Metric', 'DPID', 'Traj Smoothing', 'Change');
fprintf(fid, '%-30s %18s %18s %18s\n', repmat('-', 1, 30), repmat('-', 1, 18), repmat('-', 1, 18), repmat('-', 1, 18));
fprintf(fid, '%-30s %16.1f%% %16.1f%% %16.1f pts\n', 'Success Rate', comparison.dpid.success_rate, comparison.traj.success_rate, comparison.improvements.success_rate_pts);
fprintf(fid, '%-30s %15.1f sec %15.1f sec %18s\n', 'Cycle Time', comparison.dpid.cycle_time, comparison.traj.cycle_time, '-');
fprintf(fid, '%-30s %15.2f s/d %15.2f s/d %18s\n', 'Time per Dish', comparison.dpid.time_per_dish, comparison.traj.time_per_dish, '-');
fprintf(fid, '%-30s %16d/64 %16d/64 %18s\n', 'Dishes Completed', comparison.dpid.dishes_completed, comparison.traj.dishes_completed, '-');
fprintf(fid, '%-30s %16.1f%% %16.1f%% %18s\n\n', 'Completion Rate', comparison.dpid.completion_rate, comparison.traj.completion_rate, '-');

%% Technical Analysis
fprintf(fid, '========================================================================================================\n');
fprintf(fid, 'TECHNICAL ANALYSIS\n');
fprintf(fid, '========================================================================================================\n\n');

fprintf(fid, 'ERROR REDUCTION MECHANISMS:\n');
fprintf(fid, '--------------------------------\n');
fprintf(fid, '1. Trajectory Smoothing (Primary Factor)\n');
fprintf(fid, '   • Eliminates step changes in position targets\n');
fprintf(fid, '   • Provides continuous velocity and acceleration references\n');
fprintf(fid, '   • Reduces PID derivative kick and overshoot\n');

fprintf(fid, '2. Feedforward Control (Secondary Factor)\n');
fprintf(fid, '   • Anticipates required forces based on trajectory\n');
fprintf(fid, '   • Reduces lag in response to planned motion\n');
fprintf(fid, '   • Complements PID feedback for better tracking\n');

fprintf(fid, '3. Parameter Optimisation (Tertiary Factor)\n');
fprintf(fid, '   • Fine-tunes gains for smooth trajectory system\n');
fprintf(fid, '   • Higher gains compensate for predictable dynamics\n');
fprintf(fid, '   • Axis ratio optimisation improves multi-axis coordination\n');

%% Conclusions
fprintf(fid, '========================================================================================================\n');
fprintf(fid, 'CONCLUSIONS AND RECOMMENDATIONS\n');
fprintf(fid, '========================================================================================================\n\n');

fprintf(fid, 'CONCLUSIONS:\n');
fprintf(fid, '-------------\n');
fprintf(fid, '1. Trajectory smoothing provides the largest single improvement to system performance\n');
fprintf(fid, '   (%.1f%% reduction in mean error).\n\n', comparison.improvements.mean_error_pct);

fprintf(fid, '2. Bayesian optimisation efficiently discovered optimal parameters in minimal time\n');
fprintf(fid, '   (50 trials vs 177,147 for equivalent grid search).\n\n');

fprintf(fid, '3. The combined approach (smoothing + feedforward + optimisation) achieves\n');
fprintf(fid, '   sub-4mm mean error with 100%% success rate and full completion.\n\n');

fprintf(fid, '4. Axis ratio optimisation revealed that assumed ratios were close to optimal,\n');
fprintf(fid, '   validating the original system design.\n\n');

fprintf(fid, 'RECOMMENDATIONS:\n');
fprintf(fid, '-----------------\n');
fprintf(fid, '1. IMMEDIATE: Deploy trajectory smoothing system with optimised parameters if accuracy is priority.\n');
fprintf(fid, '   - Provides immediate %.1f%% error reduction\n', comparison.improvements.mean_error_pct);
fprintf(fid, '   - No additional hardware required\n');
fprintf(fid, '   - Validated through 50 optimisation trials\n\n');

fprintf(fid, '2. SHORT-TERM: Optimise feedforward gain independently\n');
fprintf(fid, '   - Current FF_gain = 1.0 assumes perfect model\n');
fprintf(fid, '   - 1D sweep of [0.7-1.3] could yield additional improvement\n\n');

fprintf(fid, '3. MEDIUM-TERM: Implement state observer for velocity estimation\n');
fprintf(fid, '   - Reduce noise in derivative term\n');
fprintf(fid, '   - Enable more aggressive Kd tuning\n\n');

fprintf(fid, '4. LONG-TERM: Investigate Model Predictive Control (MPC)\n');
fprintf(fid, '   - Constraint handling for workspace boundaries\n');
fprintf(fid, '   - Multi-step trajectory optimisation\n\n');

%% Footer
fprintf(fid, '========================================================================================================\n');
fprintf(fid, 'END OF REPORT\n');
fprintf(fid, '========================================================================================================\n\n');

fprintf(fid, 'Generated by: generate_performance_report.m\n');
fprintf(fid, 'Data files: system_comparison.mat, performance_dpid.mat, performance_traj.mat\n');
fprintf(fid, 'Visualisation: Use compare_system_versions.m for plots\n\n');

fclose(fid);

%% Display completion message
fprintf('\n========================================\n');
fprintf('REPORT GENERATION COMPLETE\n');
fprintf('========================================\n\n');
fprintf('Report saved to: Performance_Report.txt\n');
fprintf('Open with any text editor for viewing.\n\n');
fprintf('To view now, run: type Performance_Report.txt\n');
fprintf('========================================\n');

% Also display key results to console
fprintf('\nKEY RESULTS:\n');
fprintf('  Mean Error: %.1fmm → %.1fmm (%.1f%% reduction)\n', ...
    comparison.dpid.mean_error, comparison.traj.mean_error, comparison.improvements.mean_error_pct);
fprintf('  Success Rate: %.1f%% → %.1f%%\n', ...
    comparison.dpid.success_rate, comparison.traj.success_rate);
fprintf('  Completion: %d/64 → %d/64 dishes\n\n', ...
    comparison.dpid.dishes_completed, comparison.traj.dishes_completed);