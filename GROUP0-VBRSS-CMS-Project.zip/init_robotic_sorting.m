%% init_robotic_sorting_simulink.m
% Initialisation script for Robotic Sorting System Simulink Model
% (Trajectory Smoothing / "current" model)
% Run this before starting the simulation
% Group 0 - 49329 Control of Mechatronic Systems
% Author: Jason T Stewart

% Clear workspace but preserve database if it exists
if exist('database_state.mat', 'file')
    load('database_state.mat', 'Area1_Types', 'Area1_Counts', 'Completed_Types');
    temp_types = Area1_Types;
    temp_counts = Area1_Counts;
    temp_completed = Completed_Types;
    clearvars -except test_* models all_good stop_time run_dpid run_traj metrics_dpid metrics_traj  % PRESERVE test parameters and tuning variables!
else
    clearvars -except test_* models all_good stop_time run_dpid run_traj metrics_dpid metrics_traj
end

close all; clc;

fprintf('========================================\n');
fprintf('ROBOTIC SORTING SYSTEM - SIMULINK INIT\n');
fprintf('========================================\n\n');

%% Initialise Database Arrays (SINGLE VERSION ONLY)
if exist('temp_types', 'var')
    % Restore from previous session
    Area1_Types = temp_types;
    Area1_Counts = temp_counts;
    Completed_Types = temp_completed;
    clear temp_*
    fprintf('=== DATABASE RESTORED FROM PREVIOUS SESSION ===\n');
else
    % Fresh start
    Area1_Types = zeros(1, 16);
    Area1_Counts = zeros(1, 16);
    Completed_Types = zeros(1, 100);
    fprintf('=== FRESH DATABASE INITIALISED ===\n');
end

% Display current state
occupied_slots = sum(Area1_Counts > 0);
full_slots = sum(Area1_Counts >= 10);
completed_count = sum(Completed_Types > 0);

fprintf('Area 1: %d slots occupied, %d at capacity\n', occupied_slots, full_slots);
fprintf('Completed types: %d\n', completed_count);

if full_slots > 0
    fprintf('\nWARNING: %d slots ready for removal!\n', full_slots);
    fprintf('Run process_after_simulation.m after simulation to clear them.\n');
end

fprintf('========================================\n\n');

%% Test Mode Configuration
if ~exist('test_mode', 'var')
    test_mode = 0;  % Normal operation
end

if ~exist('max_dishes_test', 'var')
    max_dishes_test = 20;  % Default test size
end

%% System Configuration

% Workspace dimensions (mm)
config.workspace.width = 1300;
config.workspace.length = 800;
config.workspace.height = 300;

% Area definitions
config.area0.center_x = 100;
config.area0.center_y = 400;
config.area0.stacks = 4;
config.area0.dishes_per_stack = 16;

config.area1.start_x = 200;
config.area1.start_y = 0;
config.area1.slots = 16;
config.area1.rows = 2;          % 2 rows
config.area1.cols = 8;          % 8 columns
config.area1.max_per_slot = 10;

config.area2.center_x = 1200;
config.area2.center_y = 400;

config.area3.center_x = 650;
config.area3.center_y = 600;

%% Robot Dynamics Parameters
% Mass for each axis (kg)
robot.mass.x = 5;
robot.mass.y = 3;
robot.mass.z = 2;

% Damping coefficients (N·s/m)
% Check for test parameters first
if exist('test_damping_x', 'var')
    robot.damping.x = test_damping_x;
    robot.damping.y = test_damping_y;
    robot.damping.z = test_damping_z;
    fprintf('Using TEST damping values: X=%.0f, Y=%.0f, Z=%.0f\n', ...
        robot.damping.x, robot.damping.y, robot.damping.z);
else
    robot.damping.x = 50;
    robot.damping.y = 30;
    robot.damping.z = 20;
end

% Spring constants (N/m)
robot.spring.x = 1000;
robot.spring.y = 1000;
robot.spring.z = 1500;

% Transfer functions for each axis
% G(s) = 1/(Ms^2 + Bs + K)
robot.tf.x = tf(1, [robot.mass.x, robot.damping.x, robot.spring.x]);
robot.tf.y = tf(1, [robot.mass.y, robot.damping.y, robot.spring.y]);
robot.tf.z = tf(1, [robot.mass.z, robot.damping.z, robot.spring.z]);

%% State-Space Model
g = 9.81;  % gravity

% Effective masses
mass_eff.x = 10;  % kg (5+3+2 - X carries everything)
mass_eff.y = 5;   % kg (3+2 - Y carries Z)
mass_eff.z = 2;   % kg

% Full 6x6 system matrices
A_full = [0   1   0   0   0   0;
          0  -robot.damping.x/mass_eff.x  0   0   0   0;
          0   0   0   1   0   0;
          0   0   0  -robot.damping.y/mass_eff.y  0   0;
          0   0   0   0   0   1;
          0   0   0   0   0  -robot.damping.z/mass_eff.z];

% CRITICAL FIX: 1000x scaling for mm output (not metres!)
B_full = [0   0   0;
          1000/mass_eff.x   0   0;
          0   0   0;
          0   1000/mass_eff.y   0;
          0   0   0;
          0   0   1000/mass_eff.z];

C_full = [1 0 0 0 0 0;  % output px
          0 0 1 0 0 0;  % output py
          0 0 0 0 1 0]; % output pz

D_full = zeros(3,3);

% Gravity compensation
Fz_gravity = mass_eff.z * g;  % About 19.6 N

%% Motion Constraints
% Maximum velocities (mm/s)
constraints.vel_max = [500; 500; 300];  % [x; y; z]

% Maximum accelerations (mm/s^2)
constraints.acc_max = [1000; 1000; 500];  % [x; y; z]

% Position limits
constraints.pos_min = [0; 0; 0];
constraints.pos_max = [config.workspace.width; 
                       config.workspace.length; 
                       config.workspace.height];

%% PID Controller Parameters
% Check for test parameters from optimisation
if exist('test_Ki_x', 'var')
    fprintf('Using TEST PID parameters\n');
    
    % X-axis - use test values if available, otherwise defaults
    if exist('test_Kp_x', 'var')
        pid.x.Kp = test_Kp_x;
    else
        pid.x.Kp = 200;
    end
    pid.x.Ki = test_Ki_x;
    if exist('test_Kd_x', 'var')
        pid.x.Kd = test_Kd_x;
    else
        pid.x.Kd = 10;
    end
    
    % Y-axis
    if exist('test_Kp_y', 'var')
        pid.y.Kp = test_Kp_y;
    else
        pid.y.Kp = 200;
    end
    pid.y.Ki = test_Ki_y;
    if exist('test_Kd_y', 'var')
        pid.y.Kd = test_Kd_y;
    else
        pid.y.Kd = 10;
    end
    
    % Z-axis
    if exist('test_Kp_z', 'var')
        pid.z.Kp = test_Kp_z;
    else
        pid.z.Kp = 300;
    end
    pid.z.Ki = test_Ki_z;
    if exist('test_Kd_z', 'var')
        pid.z.Kd = test_Kd_z;
    else
        pid.z.Kd = 15;
    end
    
    fprintf('  X-axis: Kp=%.0f, Ki=%.0f, Kd=%.0f\n', pid.x.Kp, pid.x.Ki, pid.x.Kd);
    fprintf('  Y-axis: Kp=%.0f, Ki=%.0f, Kd=%.0f\n', pid.y.Kp, pid.y.Ki, pid.y.Kd);
    fprintf('  Z-axis: Kp=%.0f, Ki=%.0f, Kd=%.0f\n', pid.z.Kp, pid.z.Ki, pid.z.Kd);
else
    % Use default parameters
    fprintf('Using DEFAULT PID parameters\n');
    
    % X-axis PID
    pid.x.Kp = 200;
    pid.x.Ki = 20;
    pid.x.Kd = 10;
    
    % Y-axis PID
    pid.y.Kp = 200;
    pid.y.Ki = 20;
    pid.y.Kd = 10;
    
    % Z-axis PID
    pid.z.Kp = 300;
    pid.z.Ki = 30;
    pid.z.Kd = 15;
end

% Common settings for all axes
pid.x.filter_coeff = 100;  % Derivative filter
pid.y.filter_coeff = 100;
pid.z.filter_coeff = 100;

%% MPC Parameters (placeholder)
mpc.prediction_horizon = 10;
mpc.control_horizon = 3;
mpc.sample_time = 0.01;  % 10ms
mpc.weights.output = [1; 1; 2];  % Position tracking weights
mpc.weights.mv_rate = [0.1; 0.1; 0.2];  % Control effort weights

%% Simulation Parameters
sim.dt = 0.001;  % 1ms sample time

% Use test mode settings if applicable
if test_mode
    sim.session_dishes = max_dishes_test;
    fprintf('TEST MODE: Processing %d dishes only\n', max_dishes_test);
else
    sim.session_dishes = 64;
end

sim.total_sessions = 10;

%% Database Session tracking
% Session tracking
database.session_number = 0;
database.lifetime_sorted = 0;
database.disposal_count = 0;
database.buffer_count = 0;

%% Generate Input Dishes 
rng('shuffle');   % Randomise input material to simulate production environment better than fixed seed
dishes.all_types = zeros(1, 64);
for i = 1:64
    x = randi(3);
    y = randi(3);
    z = randi(3);
    dishes.all_types(i) = x*100 + y*10 + z;
end

% Organise by stack
dishes.stacks = reshape(dishes.all_types, [16, 4])';

%% Pre-computed Smooth Trajectories (FLATTENED)
fprintf('Generating smooth trajectories...\n');

% Pre-allocate flat storage
max_time_steps = 2000;  % Generous upper bound
num_trajectories = 156;

% Flat arrays
TRAJ_TIME = zeros(num_trajectories, max_time_steps);
TRAJ_POSITION = zeros(num_trajectories, max_time_steps, 3);
TRAJ_VELOCITY = zeros(num_trajectories, max_time_steps, 3);
TRAJ_ACCELERATION = zeros(num_trajectories, max_time_steps, 3);
TRAJ_DURATION = zeros(num_trajectories, 1);
TRAJ_LENGTH = zeros(num_trajectories, 1);  % Actual number of time steps

% Lookup table: [stack, dest_area, dest_index] -> trajectory_id
% Area 1: indices 1-64
% Area 2: indices 65-92
% Area 3: indices 93-156

traj_id = 0;

% Generate all trajectories
for stack = 1:4
    input_pos = [100, 100 + (stack-1)*200, 100];
    
    % Area 1 (slots 1-16)
    for slot = 1:16
        traj_id = traj_id + 1;
        row = floor((slot-1)/8) + 1;
        col = mod(slot-1, 8) + 1;
        dest_pos = [250 + (col-1)*100, 50 + (row-1)*100, 50];
        
        waypoints = [input_pos; 
                     input_pos(1), input_pos(2), 250;
                     dest_pos(1), dest_pos(2), 250;
                     dest_pos];
        
        traj = generate_smooth_trajectory(waypoints, [250; 350; 250]);
        
        % Store in flat arrays
        n = length(traj.time);
        TRAJ_TIME(traj_id, 1:n) = traj.time;
        TRAJ_POSITION(traj_id, 1:n, :) = traj.position;
        TRAJ_VELOCITY(traj_id, 1:n, :) = traj.velocity;
        TRAJ_ACCELERATION(traj_id, 1:n, :) = traj.acceleration;
        TRAJ_DURATION(traj_id) = traj.duration;
        TRAJ_LENGTH(traj_id) = n;
    end
    
    % Area 2 (7 disposal rows)
    for row_idx = 1:7
        traj_id = traj_id + 1;
        dest_pos = [1200, 50 + (row_idx-1)*110, 100];
        
        waypoints = [input_pos;
                     input_pos(1), input_pos(2), 250;
                     dest_pos(1), dest_pos(2), 150;
                     dest_pos];
        
        traj = generate_smooth_trajectory(waypoints, [250; 400; 200]);
        
        n = length(traj.time);
        TRAJ_TIME(traj_id, 1:n) = traj.time;
        TRAJ_POSITION(traj_id, 1:n, :) = traj.position;
        TRAJ_VELOCITY(traj_id, 1:n, :) = traj.velocity;
        TRAJ_ACCELERATION(traj_id, 1:n, :) = traj.acceleration;
        TRAJ_DURATION(traj_id) = traj.duration;
        TRAJ_LENGTH(traj_id) = n;
    end
    
    % Area 3 (16 buffer slots)
    for buf_slot = 1:16
        traj_id = traj_id + 1;
        buf_row = floor((buf_slot-1)/8) + 1;
        buf_col = mod(buf_slot-1, 8) + 1;
        dest_pos = [250 + (buf_col-1)*100, 450 + (buf_row-1)*150, 50];
        
        waypoints = [input_pos;
                     input_pos(1), input_pos(2), 250;
                     dest_pos(1), dest_pos(2), 250;
                     dest_pos];
        
        traj = generate_smooth_trajectory(waypoints, [250; 350; 250]);
        
        n = length(traj.time);
        TRAJ_TIME(traj_id, 1:n) = traj.time;
        TRAJ_POSITION(traj_id, 1:n, :) = traj.position;
        TRAJ_VELOCITY(traj_id, 1:n, :) = traj.velocity;
        TRAJ_ACCELERATION(traj_id, 1:n, :) = traj.acceleration;
        TRAJ_DURATION(traj_id) = traj.duration;
        TRAJ_LENGTH(traj_id) = n;
    end
end

fprintf('Generated %d smooth trajectories.\n', traj_id);

%% State Machine Configuration
states.list = {'IDLE', 'SELECT_DISH', 'MOVE_TO_PICK', 'READ_LABEL', ...
               'DETERMINE_DEST', 'PICK', 'MOVE_TO_PLACE', 'PLACE', ...
               'COMPLETE'};
states.initial = 'IDLE';
states.timeout = 10;  % Max time in any state (seconds)

%% Initialise Logging Variables
log.time = [];
log.state = [];
log.position = [];
log.error = [];
log.sorting_decisions = [];

%% Display Configuration Summary
fprintf('\n=== CONFIGURATION SUMMARY ===\n');
fprintf('Workspace: %dx%dx%d mm\n', config.workspace.width, ...
        config.workspace.length, config.workspace.height);
fprintf('Area 1: %d slots (%dx%d grid), max %d items/slot\n', ...
        config.area1.slots, config.area1.rows, config.area1.cols, config.area1.max_per_slot);
fprintf('Total dishes per session: %d\n', sim.session_dishes);
fprintf('Control: PID with Smooth Trajectories\n');
fprintf('Sample time: %.3f ms\n', sim.dt*1000);
if test_mode
    fprintf('Mode: TEST\n');
else
    fprintf('Mode: NORMAL\n');
end

clear sim

fprintf('\nInitialisation complete!\n');
fprintf('========================================\n\n');

%% Helper Function: Generate Smooth Trajectory
function traj = generate_smooth_trajectory(waypoints, velocities)
% Generates smooth 5th-order polynomial trajectory through waypoints

N = size(waypoints, 1);
dt = 0.001;  % 1ms sample time

if nargin < 2
    velocities = 200 * ones(N-1, 1);
end

traj.time = [];
traj.position = [];
traj.velocity = [];
traj.acceleration = [];
total_time = 0;

for i = 1:N-1
    p0 = waypoints(i, :)';
    p1 = waypoints(i+1, :)';
    
    distance = norm(p1 - p0);
    T = distance / velocities(i);
    
    coeffs = zeros(6, 3);
    
    for axis = 1:3
        A = [1,  0,    0,     0,      0,       0;
             0,  1,    0,     0,      0,       0;
             0,  0,    2,     0,      0,       0;
             1,  T,    T^2,   T^3,    T^4,     T^5;
             0,  1,    2*T,   3*T^2,  4*T^3,   5*T^4;
             0,  0,    2,     6*T,    12*T^2,  20*T^3];
        
        b = [p0(axis); 0; 0; p1(axis); 0; 0];
        coeffs(:, axis) = A \ b;
    end
    
    t_seg = 0:dt:T;
    n_samples = length(t_seg);
    
    pos_seg = zeros(n_samples, 3);
    vel_seg = zeros(n_samples, 3);
    acc_seg = zeros(n_samples, 3);
    
    for j = 1:n_samples
        t = t_seg(j);
        for axis = 1:3
            a = coeffs(:, axis);
            pos_seg(j, axis) = a(1) + a(2)*t + a(3)*t^2 + a(4)*t^3 + a(5)*t^4 + a(6)*t^5;
            vel_seg(j, axis) = a(2) + 2*a(3)*t + 3*a(4)*t^2 + 4*a(5)*t^3 + 5*a(6)*t^4;
            acc_seg(j, axis) = 2*a(3) + 6*a(4)*t + 12*a(5)*t^2 + 20*a(6)*t^3;
        end
    end
    
    traj.time = [traj.time, t_seg + total_time];
    traj.position = [traj.position; pos_seg];
    traj.velocity = [traj.velocity; vel_seg];
    traj.acceleration = [traj.acceleration; acc_seg];
    
    total_time = total_time + T;
end

traj.duration = total_time;
end