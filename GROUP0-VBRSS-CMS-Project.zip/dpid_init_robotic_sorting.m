%% dpid_init_robotic_sorting.m
% Initialisation script for Robotic Sorting System Simulink Model (DPID)
% Run this before starting the simulation
% Group 0 - 49329 Control of Mechatronic Systems
% Author: Jason T Stewart

% Clear workspace but preserve database if it exists
if exist('database_state.mat', 'file')
    load('database_state.mat', 'Area1_Types', 'Area1_Counts', 'Completed_Types');
    temp_types = Area1_Types;
    temp_counts = Area1_Counts;
    temp_completed = Completed_Types;
    clearvars -except test_* models all_good stop_time run_dpid run_traj metrics_dpid metrics_traj  % PRESERVE test parameters and tuning variables!
else
    clearvars -except test_* models all_good stop_time run_dpid run_traj metrics_dpid metrics_traj
end

close all; clc;

fprintf('========================================\n');
fprintf('ROBOTIC SORTING SYSTEM - DPID INIT\n');
fprintf('========================================\n\n');

%% Initialise Database Arrays (SINGLE VERSION ONLY)
if exist('temp_types', 'var')
    % Restore from previous session
    Area1_Types = temp_types;
    Area1_Counts = temp_counts;
    Completed_Types = temp_completed;
    clear temp_*
    fprintf('=== DATABASE RESTORED FROM PREVIOUS SESSION ===\n');
else
    % Fresh start
    Area1_Types = zeros(1, 16);
    Area1_Counts = zeros(1, 16);
    Completed_Types = zeros(1, 100);
    fprintf('=== FRESH DATABASE INITIALISED ===\n');
end

% Display current state
occupied_slots = sum(Area1_Counts > 0);
full_slots = sum(Area1_Counts >= 10);
completed_count = sum(Completed_Types > 0);

fprintf('Area 1: %d slots occupied, %d at capacity\n', occupied_slots, full_slots);
fprintf('Completed types: %d\n', completed_count);

if full_slots > 0
    fprintf('\nWARNING: %d slots ready for removal!\n', full_slots);
    fprintf('Run process_after_simulation.m after simulation to clear them.\n');
end

fprintf('========================================\n\n');

%% Test Mode Configuration
if ~exist('test_mode', 'var')
    test_mode = 0;  % Normal operation
end

if ~exist('max_dishes_test', 'var')
    max_dishes_test = 20;  % Default test size
end

%% System Configuration

% Workspace dimensions (mm)
config.workspace.width = 1300;
config.workspace.length = 800;
config.workspace.height = 300;

% Area definitions
config.area0.center_x = 100;
config.area0.center_y = 400;
config.area0.stacks = 4;
config.area0.dishes_per_stack = 16;

config.area1.start_x = 200;
config.area1.start_y = 0;
config.area1.slots = 16;
config.area1.rows = 2;          % 2 rows
config.area1.cols = 8;          % 8 columns
config.area1.max_per_slot = 10;

config.area2.center_x = 1200;
config.area2.center_y = 400;
config.area2.rows = 7;          % 7 disposal rows

config.area3.center_x = 650;
config.area3.center_y = 600;
config.area3.slots = 16;        % 16 buffer slots
config.area3.rows = 2;          % 2 rows
config.area3.cols = 8;          % 8 columns

%% Robot Dynamics Parameters
% Mass for each axis (kg)
robot.mass.x = 5;
robot.mass.y = 3;
robot.mass.z = 2;

% Damping coefficients (N·s/m)
% Check for test parameters first
if exist('test_damping_x', 'var')
    robot.damping.x = test_damping_x;
    robot.damping.y = test_damping_y;
    robot.damping.z = test_damping_z;
    fprintf('Using TEST damping values: X=%.0f, Y=%.0f, Z=%.0f\n', ...
        robot.damping.x, robot.damping.y, robot.damping.z);
else
    robot.damping.x = 50;
    robot.damping.y = 30;
    robot.damping.z = 20;
end

% Spring constants (N/m) - for compliance if needed
robot.spring.x = 1000;
robot.spring.y = 1000;
robot.spring.z = 1500;

% Transfer functions for each axis
% G(s) = 1/(Ms^2 + Bs + K)
robot.tf.x = tf(1, [robot.mass.x, robot.damping.x, robot.spring.x]);
robot.tf.y = tf(1, [robot.mass.y, robot.damping.y, robot.spring.y]);
robot.tf.z = tf(1, [robot.mass.z, robot.damping.z, robot.spring.z]);

%% State-Space Model
g = 9.81;  % gravity

% Effective masses
mass_eff.x = 10;  % kg (5+3+2 - X carries everything)
mass_eff.y = 5;   % kg (3+2 - Y carries Z)
mass_eff.z = 2;   % kg

% Full 6x6 system matrices
A_full = [0   1   0   0   0   0;
          0  -robot.damping.x/mass_eff.x  0   0   0   0;
          0   0   0   1   0   0;
          0   0   0  -robot.damping.y/mass_eff.y  0   0;
          0   0   0   0   0   1;
          0   0   0   0   0  -robot.damping.z/mass_eff.z];

% CRITICAL FIX: 1000x scaling for mm output (not metres!)
B_full = [0   0   0;
          1000/mass_eff.x   0   0;
          0   0   0;
          0   1000/mass_eff.y   0;
          0   0   0;
          0   0   1000/mass_eff.z];

C_full = [1 0 0 0 0 0;  % output px
          0 0 1 0 0 0;  % output py
          0 0 0 0 1 0]; % output pz

D_full = zeros(3,3);

% Gravity compensation
Fz_gravity = mass_eff.z * g;  % About 19.6 N

%% Motion Constraints
% Maximum velocities (mm/s)
constraints.vel_max = [500; 500; 300];  % [x; y; z]

% Maximum accelerations (mm/s^2)
constraints.acc_max = [1000; 1000; 500];  % [x; y; z]

% Position limits
constraints.pos_min = [0; 0; 0];
constraints.pos_max = [config.workspace.width; 
                       config.workspace.length; 
                       config.workspace.height];

%% PID Controller Parameters
% Check for test parameters from optimisation
if exist('test_Ki_x', 'var')
    fprintf('Using TEST PID parameters\n');
    
    % X-axis - use test values if available, otherwise defaults
    if exist('test_Kp_x', 'var')
        pid.x.Kp = test_Kp_x;
    else
        pid.x.Kp = 200;
    end
    pid.x.Ki = test_Ki_x;
    if exist('test_Kd_x', 'var')
        pid.x.Kd = test_Kd_x;
    else
        pid.x.Kd = 10;
    end
    
    % Y-axis
    if exist('test_Kp_y', 'var')
        pid.y.Kp = test_Kp_y;
    else
        pid.y.Kp = 200;
    end
    pid.y.Ki = test_Ki_y;
    if exist('test_Kd_y', 'var')
        pid.y.Kd = test_Kd_y;
    else
        pid.y.Kd = 10;
    end
    
    % Z-axis
    if exist('test_Kp_z', 'var')
        pid.z.Kp = test_Kp_z;
    else
        pid.z.Kp = 300;
    end
    pid.z.Ki = test_Ki_z;
    if exist('test_Kd_z', 'var')
        pid.z.Kd = test_Kd_z;
    else
        pid.z.Kd = 15;
    end
    
    fprintf('  X-axis: Kp=%.0f, Ki=%.0f, Kd=%.0f\n', pid.x.Kp, pid.x.Ki, pid.x.Kd);
    fprintf('  Y-axis: Kp=%.0f, Ki=%.0f, Kd=%.0f\n', pid.y.Kp, pid.y.Ki, pid.y.Kd);
    fprintf('  Z-axis: Kp=%.0f, Ki=%.0f, Kd=%.0f\n', pid.z.Kp, pid.z.Ki, pid.z.Kd);
else
    % Use default parameters
    fprintf('Using DEFAULT PID parameters\n');
    
    % X-axis PID
    pid.x.Kp = 200;
    pid.x.Ki = 20;
    pid.x.Kd = 10;
    
    % Y-axis PID
    pid.y.Kp = 200;
    pid.y.Ki = 20;
    pid.y.Kd = 10;
    
    % Z-axis PID
    pid.z.Kp = 300;
    pid.z.Ki = 30;
    pid.z.Kd = 15;
end

% Common settings for all axes
pid.x.filter_coeff = 100;  % Derivative filter
pid.y.filter_coeff = 100;
pid.z.filter_coeff = 100;

%% MPC Parameters (placeholder)
mpc.prediction_horizon = 10;
mpc.control_horizon = 3;
mpc.sample_time = 0.01;  % 10ms
mpc.weights.output = [1; 1; 2];  % Position tracking weights
mpc.weights.mv_rate = [0.1; 0.1; 0.2];  % Control effort weights

%% Simulation Parameters
sim.dt = 0.001;  % 1ms sample time

% Use test mode settings if applicable
if test_mode
    sim.session_dishes = max_dishes_test;
    fprintf('TEST MODE: Processing %d dishes only\n', max_dishes_test);
else
    sim.session_dishes = 64;
end

sim.total_sessions = 10;

%% Database Session tracking
% Session tracking
database.session_number = 0;
database.lifetime_sorted = 0;
database.disposal_count = 0;
database.buffer_count = 0;

%% Generate Input Dishes 
rng('shuffle');   
dishes.all_types = zeros(1, 64);
for i = 1:64
    x = randi(3);
    y = randi(3);
    z = randi(3);
    dishes.all_types(i) = x*100 + y*10 + z;
end

% Organise by stack
dishes.stacks = reshape(dishes.all_types, [16, 4])';

%% Destination Counts
% Note: DPID uses direct position calculation, no pre-computed paths needed
% Total possible destinations: 156 (4 stacks × 39 destinations per stack)
%   - Area 1: 16 slots (2 rows × 8 columns)
%   - Area 2: 7 disposal rows
%   - Area 3: 16 buffer slots (2 rows × 8 columns)

fprintf('Destination configuration:\n');
fprintf('  Area 1: %d slots (%dx%d grid)\n', config.area1.slots, config.area1.rows, config.area1.cols);
fprintf('  Area 2: %d disposal rows\n', config.area2.rows);
fprintf('  Area 3: %d buffer slots (%dx%d grid)\n', config.area3.slots, config.area3.rows, config.area3.cols);
fprintf('  Total: %d possible destinations per stack\n', config.area1.slots + config.area2.rows + config.area3.slots);

%% State Machine Configuration
states.list = {'IDLE', 'SELECT_DISH', 'MOVE_TO_PICK', 'READ_LABEL', ...
               'DETERMINE_DEST', 'PICK', 'MOVE_TO_PLACE', 'PLACE', ...
               'COMPLETE'};
states.initial = 'IDLE';
states.timeout = 10;  % Max time in any state (seconds)

%% Initialise Logging Variables
log.time = [];
log.state = [];
log.position = [];
log.error = [];
log.sorting_decisions = [];

%% Display Configuration Summary
fprintf('\n=== CONFIGURATION SUMMARY ===\n');
fprintf('Workspace: %dx%dx%d mm\n', config.workspace.width, ...
        config.workspace.length, config.workspace.height);
fprintf('Area 1: %d slots (%dx%d grid), max %d items/slot\n', ...
        config.area1.slots, config.area1.rows, config.area1.cols, config.area1.max_per_slot);
fprintf('Area 2: %d disposal rows\n', config.area2.rows);
fprintf('Area 3: %d buffer slots (%dx%d grid)\n', config.area3.slots, config.area3.rows, config.area3.cols);
fprintf('Total dishes per session: %d\n', sim.session_dishes);
fprintf('Control: DPID (Direct Position Control)\n');
fprintf('Sample time: %.3f ms\n', sim.dt*1000);
if test_mode
    fprintf('Mode: TEST\n');
else
    fprintf('Mode: NORMAL\n');
end

clear sim

fprintf('\nInitialisation complete!\n');
fprintf('========================================\n\n');