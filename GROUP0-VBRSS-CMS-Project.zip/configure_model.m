%% configure_model.m
% Applies validated configuration settings to Simulink models
% 
% PURPOSE:
%   Fixes common issues when opening models on different computers:
%   - Path shadowing (multiple copies of same model)
%   - SLCC compiler errors (sets Normal mode, no code generation)
%   - Solver configuration (fixed-step ode4)
%   - Data export settings (enables workspace output)
%
% USAGE:
%   1. Open MATLAB in the project directory
%   2. Run: configure_model
%   3. When prompted, enter model name (or press Enter for default)
%   4. Script applies settings and saves model
%
% WHEN TO USE:
%   - Model won't run on your system
%   - "SLCC Exception: Unhandled compiler" error
%   - Red block indicators (undefined variables)
%   - Missing simulation data in workspace after running
%   - Solver or timestep issues
%
% Group 4A - 49329 Control of Mechatronic Systems
% Author: Jason T Stewart

clear; clc;

fprintf('========================================\n');
fprintf('MODEL CONFIGURATION UTILITY\n');
fprintf('========================================\n\n');

%% Step 0: Check current directory and path
fprintf('Current directory: %s\n\n', pwd);

% Check if models exist in current directory
if ~exist('robotic_sorting_system.slx', 'file') && ...
   ~exist('dpid_robotic_sorting_system.slx', 'file')
    fprintf('WARNING: No Simulink models found in current directory!\n\n');
    fprintf('Please navigate to the project directory first:\n');
    fprintf('  >> cd ''path/to/project''\n\n');
    return;
end

% Check for path shadowing
fprintf('Checking for duplicate files on path...\n');
check_models = {'robotic_sorting_system.slx', 'dpid_robotic_sorting_system.slx'};
shadowing_detected = false;

for i = 1:length(check_models)
    found = which(check_models{i}, '-all');
    if length(found) > 1
        fprintf('WARNING: Multiple copies of %s found:\n', check_models{i});
        for j = 1:length(found)
            fprintf('   %d. %s\n', j, found{j});
        end
        shadowing_detected = true;
    end
end

if shadowing_detected
    fprintf('\nPath shadowing detected! This causes unpredictable behavior.\n');
    fprintf('RECOMMENDATION: Remove duplicate directories from path:\n');
    fprintf('  >> rmpath(''path/to/duplicate/directory'')\n\n');
    
    response = input('Continue anyway? (y/n): ', 's');
    if ~strcmpi(response, 'y')
        fprintf('Configuration cancelled.\n');
        return;
    end
end

fprintf('\n');

%% Step 1: Select model
fprintf('Available models:\n');
fprintf('  1. robotic_sorting_system (Trajectory Smoothing)\n');
fprintf('  2. dpid_robotic_sorting_system (Direct PID)\n');
fprintf('  3. Both models\n');
fprintf('  4. Custom (enter model name)\n\n');

choice = input('Select option [1-4] (default=1): ', 's');

if isempty(choice)
    choice = '1';
end

switch choice
    case '1'
        models = {'robotic_sorting_system'};
    case '2'
        models = {'dpid_robotic_sorting_system'};
    case '3'
        models = {'robotic_sorting_system', 'dpid_robotic_sorting_system'};
    case '4'
        custom_model = input('Enter model name (without .slx): ', 's');
        models = {custom_model};
    otherwise
        models = {'robotic_sorting_system'};
end

fprintf('\n');

%% Step 2: Process each model
for i = 1:length(models)
    model_name = models{i};
    
    fprintf('========================================\n');
    fprintf('Configuring: %s\n', model_name);
    fprintf('========================================\n\n');
    
    % Check if model exists
    if ~exist([model_name '.slx'], 'file')
        fprintf('✗ ERROR: %s.slx not found in current directory!\n', model_name);
        fprintf('  Current directory: %s\n\n', pwd);
        continue;
    end
    
    % Load model
    try
        load_system(model_name);
        fprintf('Model loaded\n');
    catch ME
        fprintf('ERROR loading model: %s\n\n', ME.message);
        continue;
    end
    
    % Show current configuration
    fprintf('\nCurrent settings:\n');
    fprintf('  Simulation Mode:     %s\n', get_param(model_name, 'SimulationMode'));
    fprintf('  Compiler Opt:        %s\n', get_param(model_name, 'SimCompilerOptimization'));
    fprintf('  Solver:              %s\n', get_param(model_name, 'Solver'));
    fprintf('  Fixed Step:          %s\n', get_param(model_name, 'FixedStep'));
    fprintf('  Stop Time:           %s\n', get_param(model_name, 'StopTime'));
    
    % Apply configuration
    fprintf('\nApplying portable configuration...\n');
    
    try
        % CRITICAL: Force Normal mode (fixes SLCC compiler errors)
        set_param(model_name, 'SimulationMode', 'normal');
        set_param(model_name, 'SimCompilerOptimization', 'off');
        fprintf('  Set to Normal simulation mode (no compiler needed)\n');
        
        % Solver settings (validated configuration)
        set_param(model_name, 'Solver', 'ode4');
        set_param(model_name, 'SolverType', 'Fixed-step');
        set_param(model_name, 'FixedStep', '0.001');
        set_param(model_name, 'StopTime', '300');
        fprintf('  Configured solver: ode4 (Runge-Kutta)\n');
        fprintf('  Fixed timestep: 0.001s (1ms)\n');
        fprintf('  Stop time: 300s\n');
        
        % Data export settings (enables process_after_simulation.m)
        set_param(model_name, 'SaveOutput', 'on');
        set_param(model_name, 'OutputSaveName', 'yout');
        set_param(model_name, 'SaveTime', 'on');
        set_param(model_name, 'TimeSaveName', 'tout');
        set_param(model_name, 'SignalLogging', 'on');
        set_param(model_name, 'SignalLoggingName', 'logsout');
        
        % Data stores (correct parameter name)
        try
            set_param(model_name, 'DSMLogging', 'on');
            set_param(model_name, 'DSMLoggingName', 'dsmout');
            fprintf('  Enabled data export to workspace\n');
        catch
            % DSMLogging might not be available in all Simulink versions
            fprintf('  Enabled data export to workspace (data stores: version-dependent)\n');
        end
        
        % Save changes
        save_system(model_name);
        fprintf('  Changes saved to %s.slx\n', model_name);
        
    catch ME
        fprintf('  ERROR applying configuration: %s\n', ME.message);
        close_system(model_name, 0);
        continue;
    end
    
    % Verify configuration
    fprintf('\nVerified settings:\n');
    fprintf('  Simulation Mode:     %s\n', get_param(model_name, 'SimulationMode'));
    fprintf('  Solver:              %s (step=%ss)\n', ...
            get_param(model_name, 'Solver'), get_param(model_name, 'FixedStep'));
    fprintf('  Stop Time:           %ss\n', get_param(model_name, 'StopTime'));
    
    % Close model
    close_system(model_name);
    fprintf('\nConfiguration complete for %s\n\n', model_name);
end

%% Step 3: Test suggestion
fprintf('========================================\n');
fprintf('NEXT STEPS\n');
fprintf('========================================\n\n');

fprintf('Configuration applied successfully!\n\n');
fprintf('Recommended: Test the model with a simulation\n\n');

if any(strcmp(models, 'robotic_sorting_system'))
    fprintf('For Trajectory Smoothing model:\n');
    fprintf('  >> init_robotic_sorting\n');
    fprintf('  >> sim(''robotic_sorting_system'', ''StopTime'', ''300'')\n');
    fprintf('  >> process_after_simulation\n\n');
end

if any(strcmp(models, 'dpid_robotic_sorting_system'))
    fprintf('For Direct PID model:\n');
    fprintf('  >> dpid_init_robotic_sorting\n');
    fprintf('  >> sim(''dpid_robotic_sorting_system'', ''StopTime'', ''300'')\n');
    fprintf('  >> process_after_simulation\n\n');
end

fprintf('NOTE: Each simulation processes 64 dishes and takes:\n');
fprintf('  - TS model: ~4-5 minutes real time (includes trajectory generation)\n');
fprintf('  - DPID model: ~1-2 minutes real time\n\n');

fprintf('If simulation runs successfully, configuration is correct!\n');
fprintf('If issues persist, see User Guide troubleshooting section.\n\n');

fprintf('========================================\n');
fprintf('END OF CONFIGURATION\n');
fprintf('========================================\n');