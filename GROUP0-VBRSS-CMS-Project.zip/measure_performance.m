function metrics = measure_performance(model_name, stop_time, run_label)
% Measures comprehensive performance metrics for a robotic sorting system
%
% Inputs:
%   model_name: Name of Simulink model (e.g., 'robotic_sorting_system')
%   stop_time: Simulation duration in seconds (default: 300)
%   run_label: Descriptive label for this run (default: 'Test Run')
%
% Outputs:
%   metrics: Struct containing all performance measurements

% Group 0 - 49329 CMS
% Author: Jason T Stewart

if nargin < 2
    stop_time = 300;
end
if nargin < 3
    run_label = 'Test Run';
end

fprintf('\n========================================\n');
fprintf('PERFORMANCE MEASUREMENT: %s\n', run_label);
fprintf('========================================\n\n');

fprintf('Running simulation for %.0f seconds...\n', stop_time);
tic;

try
    % Run simulation
    simOut = sim(model_name, 'StopTime', num2str(stop_time));
    sim_time = toc;
    
    fprintf('Simulation completed in %.1f seconds\n\n', sim_time);
    
    % Extract signals
    mean_error = extract_signal(simOut, 'mean_error', NaN);
    success_rate = extract_signal(simOut, 'success_rate', 0);
    dish_idx = extract_signal(simOut, 'dish_idx', 0);
    
    % Extract time-series data for detailed analysis
    % Try both naming schemes (trajectory smoothing vs DPID)
    position = extract_timeseries(simOut, 'position');
    if isempty(position)
        position = extract_timeseries(simOut, 'dpid_position');
    end
    
    target_position = extract_timeseries(simOut, 'target_position');
    if isempty(target_position)
        target_position = extract_timeseries(simOut, 'dpid_target_position');
    end
    
    % Calculate dishes completed
    dishes_completed = max(0, dish_idx - 1);
    
    % Calculate error metrics
    if ~isempty(position) && ~isempty(target_position)
        % Compute tracking error over time
        error_trajectory = sqrt(sum((position - target_position).^2, 2));
        
        metrics.mean_error = mean_error;
        metrics.max_error = max(error_trajectory);
        metrics.std_error = std(error_trajectory);
        metrics.rms_error = sqrt(mean(error_trajectory.^2));
        
        % Error percentiles
        metrics.error_95th = prctile(error_trajectory, 95);
        metrics.error_99th = prctile(error_trajectory, 99);
        
        % Save the trajectory for plotting
        metrics.error_trajectory = error_trajectory;
        metrics.time_vector = (0:length(error_trajectory)-1) * 0.001;  % Assuming 1 ms sample time
    else
        % Fallback if trajectory data unavailable
        metrics.mean_error = mean_error;
        metrics.max_error = NaN;
        metrics.std_error = NaN;
        metrics.rms_error = NaN;
        metrics.error_95th = NaN;
        metrics.error_99th = NaN;
        metrics.error_trajectory = [];
        metrics.time_vector = [];
    end
    
    % Performance metrics
    metrics.success_rate = success_rate;
    metrics.dishes_completed = dishes_completed;
    metrics.completion_rate = (dishes_completed / 64) * 100;
    
    % Timing metrics
    metrics.cycle_time = stop_time;
    if dishes_completed > 0
        metrics.time_per_dish = stop_time / dishes_completed;
    else
        metrics.time_per_dish = Inf;
    end
    
    % System info
    metrics.run_label = run_label;
    metrics.timestamp = datetime('now');
    metrics.model = model_name;
    
    % Extract parameter info from workspace
    if evalin('base', 'exist(''pid'', ''var'')')
        pid_struct = evalin('base', 'pid');
        metrics.params.Kp_x = pid_struct.x.Kp;
        metrics.params.Ki_x = pid_struct.x.Ki;
        metrics.params.Kd_x = pid_struct.x.Kd;
        metrics.params.Kp_y = pid_struct.y.Kp;
        metrics.params.Ki_y = pid_struct.y.Ki;
        metrics.params.Kd_y = pid_struct.y.Kd;
        metrics.params.Kp_z = pid_struct.z.Kp;
        metrics.params.Ki_z = pid_struct.z.Ki;
        metrics.params.Kd_z = pid_struct.z.Kd;
    end
    
    if evalin('base', 'exist(''robot'', ''var'')')
        robot_struct = evalin('base', 'robot');
        metrics.params.damping_x = robot_struct.damping.x;
        metrics.params.damping_y = robot_struct.damping.y;
        metrics.params.damping_z = robot_struct.damping.z;
    end
    
    % Display results
    fprintf('========================================\n');
    fprintf('PERFORMANCE RESULTS\n');
    fprintf('========================================\n\n');
    
    fprintf('COMPLETION:\n');
    fprintf('  Dishes processed: %d/64 (%.1f%%)\n', ...
        dishes_completed, metrics.completion_rate);
    fprintf('  Success rate: %.1f%%\n', success_rate);
    fprintf('  Cycle time: %.1f seconds\n', stop_time);
    fprintf('  Time per dish: %.2f seconds\n\n', metrics.time_per_dish);
    
    fprintf('ACCURACY:\n');
    fprintf('  Mean error: %.2f mm\n', metrics.mean_error);
    fprintf('  RMS error: %.2f mm\n', metrics.rms_error);
    fprintf('  Std dev: %.2f mm\n', metrics.std_error);
    fprintf('  Max error: %.2f mm\n', metrics.max_error);
    fprintf('  95th percentile: %.2f mm\n', metrics.error_95th);
    fprintf('  99th percentile: %.2f mm\n\n', metrics.error_99th);
    
    fprintf('========================================\n');
    
catch ME
    fprintf('ERROR during simulation: %s\n', ME.message);
    
    % Return partial metrics
    metrics.run_label = run_label;
    metrics.timestamp = datetime('now');
    metrics.error = ME.message;
    metrics.success = false;
end

end

%% Helper functions
function value = extract_signal(simOut, signal_name, default_value)
    try
        if isprop(simOut, signal_name)
            data = simOut.(signal_name);
            value = process_data(data, signal_name, default_value);
            return;
        end
        
        if isprop(simOut, 'logsout')
            signal = simOut.logsout.getElement(signal_name);
            if ~isempty(signal)
                value = process_data(signal.Values, signal_name, default_value);
                return;
            end
        end
        
        value = default_value;
    catch
        value = default_value;
    end
end

function value = process_data(data, signal_name, default_value)
    try
        if isa(data, 'timeseries')
            values = data.Data;
        elseif isstruct(data) && isfield(data, 'Data')
            values = data.Data;
        elseif isnumeric(data)
            values = data;
        else
            value = default_value;
            return;
        end
        
        if ~isempty(values)
            if strcmp(signal_name, 'mean_error')
                % Average last 25% for mean error
                steady_idx = max(1, round(0.75*length(values))):length(values);
                value = mean(values(steady_idx));
            else
                value = values(end);
            end
        else
            value = default_value;
        end
    catch
        value = default_value;
    end
end

function data_out = extract_timeseries(simOut, signal_name)
    try
        if isprop(simOut, signal_name)
            data = simOut.(signal_name);
            if isa(data, 'timeseries')
                data_out = data.Data;
            elseif isnumeric(data)
                data_out = data;
            else
                data_out = [];
            end
            return;
        end
        
        if isprop(simOut, 'logsout')
            signal = simOut.logsout.getElement(signal_name);
            if ~isempty(signal) && isa(signal.Values, 'timeseries')
                data_out = signal.Values.Data;
                return;
            end
        end
        
        data_out = [];
    catch
        data_out = [];
    end
end