%% process_after_simulation.m
% Only processes NEW simulation data
% Use check_state.m to view current state without processing
% Group 0 - 49329 CMS
% Author: Jason T Stewart

clear temp_*  % Clean any temporary variables

fprintf('\n========================================\n');
fprintf('POST-SIMULATION PROCESSING\n');
fprintf('========================================\n\n');

%% Step 1: Check for simulation data (REQUIRED - ERROR IF SIM NOT RUN BEFOREHAND)
if ~exist('area1_types', 'var') || ~exist('area1_counts', 'var') || ~exist('completed_types', 'var') % checks for variables from "to workspace" blocks
    fprintf('ERROR: No simulation data found in workspace.\n');
    fprintf('Run simulation first, then immediately run this script.\n');
    fprintf('To view current state without simulation, use: check_state\n');
    error('Simulation data required.');
end

%% Step 2: Load previous cumulative totals
if exist('database_state.mat', 'file')
    load('database_state.mat');
    % Ensure cumulative totals exist
    if ~exist('cumulative_buffer', 'var')
        cumulative_buffer = 0;
    end
    if ~exist('cumulative_disposal', 'var')
        cumulative_disposal = 0;
    end
    if ~exist('session_count', 'var')
        session_count = 0;
    end
    if ~exist('total_removed', 'var')
        total_removed = 0;
    end
else
    cumulative_buffer = 0;
    cumulative_disposal = 0;
    session_count = 0;
    total_removed = 0;
end

%% Step 3: Extract final values from simulation
% Get the last row (final state) from simulation
if size(area1_types, 1) > 1
    Area1_Types = area1_types(end, :);
    Area1_Counts = area1_counts(end, :);
    Completed_Types = completed_types(end, :);
else
    Area1_Types = area1_types;
    Area1_Counts = area1_counts;
    Completed_Types = completed_types;
end

%% Step 4: Get current run's buffer and disposal counts
current_buffer = 0;
current_disposal = 0;

if exist('buffer_count', 'var')
    if isstruct(buffer_count)
        if isfield(buffer_count, 'Data')
            current_buffer = max(buffer_count.Data);
        elseif isfield(buffer_count, 'signals')
            current_buffer = max(buffer_count.signals.values);
        end
    elseif isa(buffer_count, 'timeseries')
        current_buffer = max(buffer_count.Data);
    else
        current_buffer = max(buffer_count(:));
    end
end

if exist('disposal_count', 'var')
    if isstruct(disposal_count)
        if isfield(disposal_count, 'Data')
            current_disposal = max(disposal_count.Data);
        elseif isfield(disposal_count, 'signals')
            current_disposal = max(disposal_count.signals.values);
        end
    elseif isa(disposal_count, 'timeseries')
        current_disposal = max(disposal_count.Data);
    else
        current_disposal = max(disposal_count(:));
    end
end

%% Step 5: Update cumulative totals
cumulative_buffer = cumulative_buffer + current_buffer;
cumulative_disposal = cumulative_disposal + current_disposal;
session_count = session_count + 1;

fprintf('Processing NEW simulation data (Session #%d)\n\n', session_count);

%% Step 6: Display results
area1_total = sum(Area1_Counts);

fprintf('=== CURRENT SESSION (#%d) ===\n', session_count);
fprintf('This run processed: 64 dishes\n');
fprintf('  - To Area 1: %d dishes\n', 64 - current_buffer - current_disposal);
fprintf('  - To disposal: %d dishes\n', current_disposal);
fprintf('  - To buffer: %d dishes\n', current_buffer);

fprintf('\n=== CUMULATIVE TOTALS ===\n');
fprintf('Total sessions: %d\n', session_count);
fprintf('Total dishes processed: %d\n', session_count * 64);
fprintf('Area 1 (sorted): %d dishes\n', area1_total);
fprintf('Total to disposal: %d dishes\n', cumulative_disposal);
fprintf('Total to buffer: %d dishes\n', cumulative_buffer);
fprintf('Total removed: %d dishes (completed types)\n', total_removed);

total_accounted = area1_total + cumulative_disposal + cumulative_buffer + total_removed;
expected_total = session_count * 64;

fprintf('Total accounted: %d (should equal %d)\n', total_accounted, expected_total);

if total_accounted ~= expected_total
    fprintf('WARNING: Dish count mismatch! Check simulation.\n');
end

%% Step 7: Display Area 1 status
fprintf('\n=== AREA 1 STATUS ===\n');
for slot = 1:16
    if Area1_Counts(slot) > 0
        status = '';
        if Area1_Counts(slot) >= 10
            status = ' [READY FOR REMOVAL]';
        end
        fprintf('Slot %2d: Type %3d, Count %2d%s\n', ...
                slot, Area1_Types(slot), Area1_Counts(slot), status);
    end
end

%% Step 8: Manual processing of completed types
full_slots = find(Area1_Counts >= 10);
if ~isempty(full_slots)
    fprintf('\n=== MANUAL PROCESSING AVAILABLE ===\n');
    fprintf('%d slots are at capacity and ready for removal.\n', length(full_slots));
    
    response = input('Process completed types? (y/n): ', 's');
    
    if strcmpi(response, 'y')
        fprintf('\nProcessing completed types...\n');
        
        dishes_removed_now = 0;
        
        for slot = full_slots
            type_to_remove = Area1_Types(slot);
            
            % Add to completed types
            next_pos = find(Completed_Types == 0, 1);
            if isempty(next_pos)
                next_pos = length(Completed_Types) + 1;
                if next_pos > 100
                    fprintf('WARNING: Completed types array full!\n');
                    continue;
                end
                Completed_Types(next_pos) = 0;
            end
            
            Completed_Types(next_pos) = type_to_remove;
            fprintf('Type %d moved to completed list (position %d)\n', ...
                    type_to_remove, next_pos);
            
            % Track dishes removed
            dishes_removed_now = dishes_removed_now + Area1_Counts(slot);
            
            % Clear the slot
            Area1_Types(slot) = 0;
            Area1_Counts(slot) = 0;
        end
        
        % Update total removed count
        total_removed = total_removed + dishes_removed_now;
        
        fprintf('\nCleared %d slots from Area 1.\n', length(full_slots));
        fprintf('Removed %d dishes from system.\n', dishes_removed_now);
    else
        fprintf('Manual processing skipped. Slots remain at capacity.\n');
    end
else
    fprintf('\nNo slots at capacity. Manual processing not needed.\n');
end

%% Step 9: Save database state
save('database_state.mat', 'Area1_Types', 'Area1_Counts', 'Completed_Types', ...
     'cumulative_buffer', 'cumulative_disposal', 'session_count', 'total_removed');

fprintf('\n=== DATABASE STATE SAVED ===\n');

%% Step 10: Clear simulation variables to prevent re-use
clear area1_types area1_counts completed_types
clear buffer_count disposal_count buffer_count_max disposal_count_max

%% Step 11: Final summary
fprintf('\n=== LIFETIME SUMMARY ===\n');
fprintf('Sessions completed: %d\n', session_count);
fprintf('Area 1: %d slots occupied, %d at capacity\n', ...
        sum(Area1_Counts > 0), sum(Area1_Counts >= 10));
fprintf('Completed types: %d\n', sum(Completed_Types > 0));
fprintf('Lifetime totals:\n');
fprintf('  - Total dishes: %d\n', session_count * 64);
fprintf('  - In Area 1: %d\n', area1_total);
fprintf('  - Total disposed: %d\n', cumulative_disposal);
fprintf('  - Total buffered: %d\n', cumulative_buffer);
fprintf('  - Total removed: %d (completed types)\n', total_removed);
fprintf('========================================\n');

%% Final message
fprintf('\n');
if full_slots
    fprintf('To check updated state after removal, use: check_state\n');
else
    fprintf('To view state anytime, use: check_state\n');
end