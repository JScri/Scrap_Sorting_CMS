%% check_state.m
% Simple script to check current database state without processing
% Use this after manual removal or anytime to see current status
% Ensure you have this file open in the same workspace as the sim and process_after_simulation.m
% Group 0 - 49329 CMS
% Author: Jason T Stewart

%% Load current database
if ~exist('database_state.mat', 'file')
    fprintf('No database found. Run simulation first.\n');
    return;
end

load('database_state.mat');

%% Display header
fprintf('\n========================================\n');
fprintf('CURRENT DATABASE STATE\n');
fprintf('========================================\n\n');

%% Session info
if exist('session_count', 'var')
    fprintf('Sessions completed: %d\n', session_count);
    fprintf('Total dishes processed: %d\n', session_count * 64);
else
    fprintf('Session count not available\n');
end

%% Area totals
area1_total = sum(Area1_Counts);
fprintf('\n=== CURRENT TOTALS ===\n');
fprintf('Area 1 (sorted): %d dishes\n', area1_total);

if exist('cumulative_disposal', 'var')
    fprintf('Total disposed: %d dishes\n', cumulative_disposal);
end
if exist('cumulative_buffer', 'var')
    fprintf('Total buffered: %d dishes\n', cumulative_buffer);
end
if exist('total_removed', 'var')
    fprintf('Total removed: %d dishes (completed types)\n', total_removed);
    
    % Check accounting
    if exist('session_count', 'var')
        total_accounted = area1_total + cumulative_disposal + cumulative_buffer + total_removed;
        expected = session_count * 64;
        fprintf('\nAccounting check: %d = %d', total_accounted, expected);
        if total_accounted == expected
            fprintf(': GOOD\n');
        else
            fprintf(' [MISMATCH!]\n');
        end
    end
end

%% Area 1 detailed status
fprintf('\n=== AREA 1 SLOTS ===\n');
empty_count = 0;
full_count = 0;

for slot = 1:16
    if Area1_Counts(slot) > 0
        status = '';
        if Area1_Counts(slot) >= 10
            status = ' [READY FOR REMOVAL]';
            full_count = full_count + 1;
        end
        fprintf('Slot %2d: Type %3d, Count %2d%s\n', ...
                slot, Area1_Types(slot), Area1_Counts(slot), status);
    else
        empty_count = empty_count + 1;
    end
end

fprintf('\nSummary: %d occupied, %d empty, %d at capacity\n', ...
        16 - empty_count, empty_count, full_count);

%% Completed types
fprintf('\n=== COMPLETED TYPES ===\n');
if exist('Completed_Types', 'var') && sum(Completed_Types > 0) > 0
    completed_idx = find(Completed_Types > 0);
    for i = 1:length(completed_idx)
        fprintf('Position %2d: Type %3d\n', completed_idx(i), Completed_Types(completed_idx(i)));
    end
    fprintf('Total: %d types completed\n', length(completed_idx));
else
    fprintf('None yet\n');
end

%% Manual processing available?
if full_count > 0
    fprintf('\n!!! %d slots ready for manual processing\n', full_count);
    fprintf('Run process_after_simulation to remove completed types\n');
end

fprintf('\n========================================\n');