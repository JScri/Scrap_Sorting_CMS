%% visualise_state.m
% Load and visualise current database state
% Ensure this file is open in the same directory as the simulation and
%   shares the same workspace as process_after_simulation.m
% Group 0 - 49329 CMS
% Author: Jason T Stewart

if exist('database_state.mat', 'file')
    load('database_state.mat', 'Area1_Types', 'Area1_Counts', 'Completed_Types');
    
    figure('Name', 'Database State', 'Position', [100 100 1200 600]);
    
    % Area 1 Occupancy
    subplot(1, 2, 1);
    
    % Create colour array - blue for normal, red for full
    bar_colours = repmat([0.2 0.6 0.8], 16, 1);  % Default blue
    full_slots = find(Area1_Counts >= 10);
    if ~isempty(full_slots)
        bar_colours(full_slots, :) = repmat([0.8 0.2 0.2], length(full_slots), 1);  % Red for full
    end
    
    % Single bar plot with different colours
    b = bar(1:16, Area1_Counts, 'FaceColor', 'flat');
    b.CData = bar_colours;
    hold on;
    
    yline(10, '--r', 'Capacity', 'LineWidth', 2);
    title('Area 1 Slot Occupancy');
    xlabel('Slot Number');
    ylabel('Dish Count');
    xlim([0.5 16.5]);
    ylim([0 12]);
    grid on;
    
    % Add type labels
    for slot = 1:16
        if Area1_Counts(slot) > 0
            text(slot, Area1_Counts(slot) + 0.3, ...
                 sprintf('%d', Area1_Types(slot)), ...
                 'HorizontalAlignment', 'center', 'FontSize', 8);
        end
    end
    
    % Completed Types
    subplot(1, 2, 2);
    completed_list = Completed_Types(Completed_Types > 0);
    
    if ~isempty(completed_list)
        % Get unique types and sort them
        unique_types = unique(completed_list);
        sorted_types = sort(unique_types);
        
        % Count how many times each type was completed
        type_counts = zeros(size(sorted_types));
        for i = 1:length(sorted_types)
            type_counts(i) = sum(completed_list == sorted_types(i)) * 10;  % 10 dishes per completion
        end
        
        % Create bar graph
        bar(1:length(sorted_types), type_counts, 0.6, ...
            'FaceColor', [0.3 0.7 0.4], 'EdgeColor', [0.2 0.5 0.3], 'LineWidth', 1.5);
        
        % Set x-axis to show actual dish type numbers
        xticks(1:length(sorted_types));
        xticklabels(arrayfun(@num2str, sorted_types, 'UniformOutput', false));
        
        % Labels and formatting
        title(sprintf('Completed Types (%d types, %d dishes total)', ...
               length(sorted_types), sum(type_counts)));
        ylabel('Dishes Processed');
        xlim([0.5 length(sorted_types)+0.5]);
        ylim([0 max(type_counts)+2]);
        grid on;
        
        % Add count labels on top of bars
        for i = 1:length(sorted_types)
            text(i, type_counts(i) + 0.5, sprintf('%d', type_counts(i)), ...
                 'HorizontalAlignment', 'center', 'FontSize', 9, 'FontWeight', 'bold');
        end
        
        % Rotate x-labels if many types
        if length(sorted_types) > 8
            xtickangle(45);
        end
        
    else
        text(0.5, 0.5, 'No completed types yet', ...
             'Units', 'normalized', 'HorizontalAlignment', 'center', ...
             'FontSize', 14, 'Color', [0.5 0.5 0.5]);
        title('Completed Types (None)');
        xlim([0 10]);
        ylim([0 20]);
    end
    
else
    fprintf('No database state found. Run simulation first.\n');
end