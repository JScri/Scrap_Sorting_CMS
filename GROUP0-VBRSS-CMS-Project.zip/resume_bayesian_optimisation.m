%% resume_bayesian_optimisation.m

% Resume interrupted Bayesian optimisation from checkpoint if required
% Back-up in case interruption occurs with main optimisation run
% Gives option to also analyse existing completed .mat file
% Keep in same directory as the other "bayesian scripts" for functionality
% Lines 74, 193, 278 & 279 have reconfigurable "dpid_" functionality

% Group 0 - 49329 CMS
% Author: Jason T Stewart

fprintf('========================================\n');
fprintf('RESUME BAYESIAN OPTIMISATION\n');
fprintf('========================================\n\n');

%% Check for checkpoint
if ~exist('bayesian_optimisation_checkpoint.mat', 'file')
    error('No checkpoint found. Nothing to resume.\nRun optimise_bayesian.m to start fresh.');
end

%% Load checkpoint
load('bayesian_optimisation_checkpoint.mat', 'results');

fprintf('Checkpoint loaded successfully!\n');
fprintf('  Completed evaluations: %d\n', results.NumObjectiveEvaluations);
fprintf('  Best score so far: %.2f\n', results.MinObjective);
fprintf('  Best found at iteration: %d\n\n', results.IndexOfMinimumTrace(end));

%% Display current best parameters
best_params = results.XAtMinObjective;

fprintf('Current best parameters:\n');
fprintf('  Damping X: %.1f\n', best_params.damping_x);
fprintf('  Kp X: %.1f\n', best_params.Kp_x);
fprintf('  Ki X: %.1f\n', best_params.Ki_x);
fprintf('  Kd X: %.1f\n', best_params.Kd_x);
fprintf('  Damping Y ratio: %.3f\n', best_params.damping_y_ratio);
fprintf('  Damping Z ratio: %.3f\n\n', best_params.damping_z_ratio);

%% Ask user for continuation plan
fprintf('Options:\n');
fprintf('  1. Continue with same settings\n');
fprintf('  2. Continue with more trials\n');
fprintf('  3. Analyse current results and stop\n');
fprintf('  4. Cancel\n\n');

choice = input('Select option (1-4): ');

if choice == 4 || isempty(choice)
    fprintf('Resume cancelled.\n');
    return;
elseif choice == 3
    fprintf('Running analysis...\n\n');
    analyse_bayesian_results;
    return;
end

%% Determine additional trials
if choice == 2
    additional_trials = input('How many additional trials? (default=25): ');
    if isempty(additional_trials)
        additional_trials = 25;
    end
else
    % Assume original target was 50, continue to that
    original_target = 50;
    additional_trials = max(10, original_target - results.NumObjectiveEvaluations);
end

fprintf('\nWill run %d additional trials...\n\n', additional_trials);

%% Re-initialise system
fprintf('Re-initialising system...\n');
init_robotic_sorting; % change prefix to and from "dpid_" depending on model type being optimised/resumed

%% Re-define optimisation variables (must match original)
vars = [
    optimizableVariable('damping_x', [40, 150], 'Type', 'real');
    optimizableVariable('Kp_x', [50, 400], 'Type', 'real');
    optimizableVariable('Ki_x', [50, 600], 'Type', 'real');
    optimizableVariable('Kd_x', [2, 25], 'Type', 'real');
    
    optimizableVariable('damping_y_ratio', [0.4, 0.8], 'Type', 'real');
    optimizableVariable('Kp_y_ratio', [0.8, 1.2], 'Type', 'real');
    optimizableVariable('Ki_y_ratio', [0.8, 1.2], 'Type', 'real');
    optimizableVariable('Kd_y_ratio', [0.8, 1.2], 'Type', 'real');
    
    optimizableVariable('damping_z_ratio', [0.2, 0.6], 'Type', 'real');
    optimizableVariable('Kp_z_ratio', [1.0, 1.6], 'Type', 'real');
    optimizableVariable('Ki_z_ratio', [1.2, 2.0], 'Type', 'real');
    optimizableVariable('Kd_z_ratio', [1.2, 2.0], 'Type', 'real');
];

%% Objective function (same as optimise_bayesian.m)
objective_fun = @(params) evaluate_parameters(params);

%% Resume optimisation
fprintf('Resuming optimisation...\n');
fprintf('Target: %d total evaluations (%d new)\n\n', ...
    results.NumObjectiveEvaluations + additional_trials, additional_trials);

new_results = resume(results, ...
    'MaxObjectiveEvaluations', results.NumObjectiveEvaluations + additional_trials, ...
    'Verbose', 1, ...
    'PlotFcn', {@plotObjectiveModel, @plotMinObjective}, ...
    'OutputFcn', @save_iteration_results);

%% Extract and display results
best_params = new_results.XAtMinObjective;

fprintf('\n========================================\n');
fprintf('RESUMED OPTIMISATION COMPLETE\n');
fprintf('========================================\n\n');

fprintf('STATISTICS:\n');
fprintf('  Previous evaluations: %d\n', results.NumObjectiveEvaluations);
fprintf('  New evaluations: %d\n', additional_trials);
fprintf('  Total evaluations: %d\n', new_results.NumObjectiveEvaluations);
fprintf('  Previous best: %.2f\n', results.MinObjective);
fprintf('  Final best: %.2f\n', new_results.MinObjective);
fprintf('  Improvement: %.2f\n\n', results.MinObjective - new_results.MinObjective);

fprintf('OPTIMAL PARAMETERS:\n');
fprintf('Base X-axis:\n');
fprintf('  Damping: %.1f N·s/m\n', best_params.damping_x);
fprintf('  Kp: %.1f\n', best_params.Kp_x);
fprintf('  Ki: %.1f\n', best_params.Ki_x);
fprintf('  Kd: %.1f\n\n', best_params.Kd_x);

fprintf('Y-axis ratios:\n');
fprintf('  Damping: %.3f (Y = %.1f)\n', best_params.damping_y_ratio, ...
    best_params.damping_x * best_params.damping_y_ratio);
fprintf('  Kp: %.3f (Y = %.1f)\n', best_params.Kp_y_ratio, ...
    best_params.Kp_x * best_params.Kp_y_ratio);
fprintf('  Ki: %.3f (Y = %.1f)\n', best_params.Ki_y_ratio, ...
    best_params.Ki_x * best_params.Ki_y_ratio);
fprintf('  Kd: %.3f (Y = %.1f)\n\n', best_params.Kd_y_ratio, ...
    best_params.Kd_x * best_params.Kd_y_ratio);

fprintf('Z-axis ratios:\n');
fprintf('  Damping: %.3f (Z = %.1f)\n', best_params.damping_z_ratio, ...
    best_params.damping_x * best_params.damping_z_ratio);
fprintf('  Kp: %.3f (Z = %.1f)\n', best_params.Kp_z_ratio, ...
    best_params.Kp_x * best_params.Kp_z_ratio);
fprintf('  Ki: %.3f (Z = %.1f)\n', best_params.Ki_z_ratio, ...
    best_params.Ki_x * best_params.Ki_z_ratio);
fprintf('  Kd: %.3f (Z = %.1f)\n\n', best_params.Kd_z_ratio, ...
    best_params.Kd_x * best_params.Kd_z_ratio);

%% Save updated results
optimal_params_bayesian = struct();
optimal_params_bayesian.damping_x = best_params.damping_x;
optimal_params_bayesian.damping_y = best_params.damping_x * best_params.damping_y_ratio;
optimal_params_bayesian.damping_z = best_params.damping_x * best_params.damping_z_ratio;

optimal_params_bayesian.Kp_x = best_params.Kp_x;
optimal_params_bayesian.Kp_y = best_params.Kp_x * best_params.Kp_y_ratio;
optimal_params_bayesian.Kp_z = best_params.Kp_x * best_params.Kp_z_ratio;

optimal_params_bayesian.Ki_x = best_params.Ki_x;
optimal_params_bayesian.Ki_y = best_params.Ki_x * best_params.Ki_y_ratio;
optimal_params_bayesian.Ki_z = best_params.Ki_x * best_params.Ki_z_ratio;

optimal_params_bayesian.Kd_x = best_params.Kd_x;
optimal_params_bayesian.Kd_y = best_params.Kd_x * best_params.Kd_y_ratio;
optimal_params_bayesian.Kd_z = best_params.Kd_x * best_params.Kd_z_ratio;

optimal_params_bayesian.ratios = struct(...
    'damping_y', best_params.damping_y_ratio, ...
    'damping_z', best_params.damping_z_ratio, ...
    'Kp_y', best_params.Kp_y_ratio, ...
    'Kp_z', best_params.Kp_z_ratio, ...
    'Ki_y', best_params.Ki_y_ratio, ...
    'Ki_z', best_params.Ki_z_ratio, ...
    'Kd_y', best_params.Kd_y_ratio, ...
    'Kd_z', best_params.Kd_z_ratio);

results = new_results;  % Update for compatibility
save('bayesian_optimisation_results.mat', 'optimal_params_bayesian', 'results');

fprintf('Results saved to: bayesian_optimisation_results.mat\n');
fprintf('========================================\n\n');

fprintf('To apply these parameters:\n');
fprintf('  test_damping_x = %.1f; test_damping_y = %.1f; test_damping_z = %.1f;\n', ...
    optimal_params_bayesian.damping_x, optimal_params_bayesian.damping_y, optimal_params_bayesian.damping_z);
fprintf('  test_Kp_x = %.1f; test_Kp_y = %.1f; test_Kp_z = %.1f;\n', ...
    optimal_params_bayesian.Kp_x, optimal_params_bayesian.Kp_y, optimal_params_bayesian.Kp_z);
fprintf('  test_Ki_x = %.1f; test_Ki_y = %.1f; test_Ki_z = %.1f;\n', ...
    optimal_params_bayesian.Ki_x, optimal_params_bayesian.Ki_y, optimal_params_bayesian.Ki_z);
fprintf('  test_Kd_x = %.1f; test_Kd_y = %.1f; test_Kd_z = %.1f;\n', ...
    optimal_params_bayesian.Kd_x, optimal_params_bayesian.Kd_y, optimal_params_bayesian.Kd_z);
fprintf('  init_robotic_sorting;\n\n'); % reconfigurable "dpid_" prefix line

%% Ask if user wants to analyse
analyse = input('Run analysis now? (y/n): ', 's');
if strcmpi(analyse, 'y')
    analyse_bayesian_results;
end

%% Helper Functions (copied from optimise_bayesian.m)
function score = evaluate_parameters(params)
    damping_x = params.damping_x;
    damping_y = params.damping_x * params.damping_y_ratio;
    damping_z = params.damping_x * params.damping_z_ratio;
    
    Kp_x = params.Kp_x;
    Kp_y = params.Kp_x * params.Kp_y_ratio;
    Kp_z = params.Kp_x * params.Kp_z_ratio;
    
    Ki_x = params.Ki_x;
    Ki_y = params.Ki_x * params.Ki_y_ratio;
    Ki_z = params.Ki_x * params.Ki_z_ratio;
    
    Kd_x = params.Kd_x;
    Kd_y = params.Kd_x * params.Kd_y_ratio;
    Kd_z = params.Kd_x * params.Kd_z_ratio;
    
    assignin('base', 'test_damping_x', damping_x);
    assignin('base', 'test_damping_y', damping_y);
    assignin('base', 'test_damping_z', damping_z);
    
    assignin('base', 'test_Kp_x', Kp_x);
    assignin('base', 'test_Kp_y', Kp_y);
    assignin('base', 'test_Kp_z', Kp_z);
    
    assignin('base', 'test_Ki_x', Ki_x);
    assignin('base', 'test_Ki_y', Ki_y);
    assignin('base', 'test_Ki_z', Ki_z);
    
    assignin('base', 'test_Kd_x', Kd_x);
    assignin('base', 'test_Kd_y', Kd_y);
    assignin('base', 'test_Kd_z', Kd_z);
    
    mass_eff_x = 10;
    mass_eff_y = 5;
    mass_eff_z = 2;
    
    A_full = [0   1   0   0   0   0;
              0  -damping_x/mass_eff_x  0   0   0   0;
              0   0   0   1   0   0;
              0   0   0  -damping_y/mass_eff_y  0   0;
              0   0   0   0   0   1;
              0   0   0   0   0  -damping_z/mass_eff_z];
    
    assignin('base', 'A_full', A_full);
    
    pid_x.Kp = Kp_x;
    pid_x.Ki = Ki_x;
    pid_x.Kd = Kd_x;
    pid_x.filter_coeff = 100;
    
    pid_y.Kp = Kp_y;
    pid_y.Ki = Ki_y;
    pid_y.Kd = Kd_y;
    pid_y.filter_coeff = 100;
    
    pid_z.Kp = Kp_z;
    pid_z.Ki = Ki_z;
    pid_z.Kd = Kd_z;
    pid_z.filter_coeff = 100;
    
    assignin('base', 'pid', struct('x', pid_x, 'y', pid_y, 'z', pid_z));
    
    robot = evalin('base', 'robot');
    robot.damping.x = damping_x;
    robot.damping.y = damping_y;
    robot.damping.z = damping_z;
    assignin('base', 'robot', robot);
    
    % FULL RUN MODE - 64 dishes, 300 seconds
    assignin('base', 'test_mode', 0);
    assignin('base', 'max_dishes_test', 64);
    
    sim_timeout = 300;
    
    try
        set_param('robotic_sorting_system', 'SimulationCommand', 'update'); % reconfigurable "dpid_" prefix line
        simOut = sim('robotic_sorting_system', 'StopTime', num2str(sim_timeout)); % reconfigurable "dpid_" prefix line
        
        mean_error = extract_from_simout(simOut, 'mean_error', 1000);
        success_rate = extract_from_simout(simOut, 'success_rate', 0);
        
        % Extract final dish_idx - MUST get final value
        final_dish_idx = extract_from_simout(simOut, 'dish_idx', -999);
        
        % If extraction failed, this is a fatal error
        if final_dish_idx == -999
            fprintf('  ERROR: Could not extract dish_idx from simulation\n');
            fprintf('  Make sure To Workspace block is connected and saving dish_idx\n');
            score = 10000;  % Severe penalty
            mean_error = 1000;
            success_rate = 0;
            completion_penalty = 10000;
        else
            % Calculate penalty based on actual completion
            % Note: dish_idx = 65 means 64 dishes completed (it's the NEXT dish index)
            expected_dishes = evalin('base', 'max_dishes_test');
            dishes_completed = final_dish_idx - 1;
            
            if dishes_completed >= expected_dishes
                completion_penalty = 0;
            else
                completion_penalty = (expected_dishes - dishes_completed) * 100;
                fprintf('  [Only completed %d/%d dishes (dish_idx=%d)]\n', ...
                    dishes_completed, expected_dishes, final_dish_idx);
            end
        end
        
        if completion_penalty > 0
            score = 5000 + completion_penalty;
        elseif success_rate < 50
            score = 2000 + mean_error;
        else
            score = mean_error + (100 - success_rate) * 3;
        end
        
    catch ME
        fprintf('  FAILED: %s\n', ME.message);
        score = 10000;
    end
    
    assignin('base', 'test_mode', 0);
    
    % Log this iteration with detailed metrics
    if completion_penalty > 0
        status_str = sprintf('[INCOMPLETE: %d penalty]', completion_penalty);
    elseif success_rate < 50
        status_str = '[LOW SUCCESS]';
    else
        status_str = '[OK]';
    end
    
    fprintf('Eval: D=%.1f(%.2f,%.2f) Kp=%.1f(%.2f,%.2f) Ki=%.1f(%.2f,%.2f) Kd=%.1f(%.2f,%.2f)\n', ...
        damping_x, params.damping_y_ratio, params.damping_z_ratio, ...
        Kp_x, params.Kp_y_ratio, params.Kp_z_ratio, ...
        Ki_x, params.Ki_y_ratio, params.Ki_z_ratio, ...
        Kd_x, params.Kd_y_ratio, params.Kd_z_ratio);
    fprintf('      → Error=%.1fmm, Success=%.1f%%, Score=%.1f %s\n', ...
        mean_error, success_rate, score, status_str);
end

function stop = save_iteration_results(results, state)
    stop = false;
    if strcmp(state, 'iteration')
        save('bayesian_optimisation_checkpoint.mat', 'results');
    end
end

function value = extract_from_simout(simOut, signal_name, default_value)
    try
        if isprop(simOut, signal_name)
            data = simOut.(signal_name);
            value = process_signal_data(data, signal_name, default_value);
            return;
        end
        
        if isprop(simOut, 'logsout')
            signal = simOut.logsout.getElement(signal_name);
            if ~isempty(signal)
                data = signal.Values;
                value = process_signal_data(data, signal_name, default_value);
                return;
            end
        end
        
        value = default_value;
    catch
        value = default_value;
    end
end

function value = process_signal_data(data, signal_name, default_value)
    try
        if isa(data, 'timeseries')
            values = data.Data;
        elseif isstruct(data) && isfield(data, 'Data')
            values = data.Data;
        elseif isnumeric(data)
            values = data;
        else
            value = default_value;
            return;
        end
        
        if ~isempty(values) && length(values) > 1
            if strcmp(signal_name, 'mean_error')
                % For mean_error, average the last 25% (steady state)
                steady_idx = max(1, round(0.75*length(values))):length(values);
                value = mean(values(steady_idx));
            else
                % For everything else (dish_idx, success_rate), use FINAL value
                value = values(end);
            end
        elseif ~isempty(values)
            value = values(end);  % Single value case
        else
            value = default_value;
        end
    catch
        value = default_value;
    end
end