%% compare_system_versions.m
% Compares DPID (discrete waypoint) vs Trajectory Smoothing implementations
% Manually input optimal parameters from optimise_bayesian.m to run ...
%   comparison with optimal parameters
% Requires measure_performance.m, init scripts and sims in same directory

% Current version (7th October 2025) does not parse cycle time properly
% Manual correction in Performance Report required for time-related metrics

% Group 0 - 49239 CMS
% Author: Jason T Stewart

fprintf('========================================\n');
fprintf('ROBOTIC SORTING SYSTEM COMPARISON\n');
fprintf('DPID vs Trajectory Smoothing\n');
fprintf('========================================\n\n');

%% Configuration
stop_time = 300;  % Simulation duration
run_dpid = true;  % Set to false to skip DPID if already measured
run_traj = true;  % Set to false to skip trajectory smoothing if already measured

%% Test 1: DPID System (Discrete Waypoints)
if run_dpid
    fprintf('\n=== TEST 1: DPID SYSTEM ===\n');
    fprintf('Running discrete waypoint system with default parameters...\n\n');
    
    % Clear workspace but preserve configuration
    clearvars -except stop_time run_dpid run_traj
    
    % Set Bayesian-optimised DPID parameters
    test_damping_x = 142.2; 
    test_damping_y = 64.3; 
    test_damping_z = 39.1;
    test_Kp_x = 106.1; 
    test_Kp_y = 122.6; 
    test_Kp_z = 136.3;
    test_Ki_x = 513.8; 
    test_Ki_y = 456.5; 
    test_Ki_z = 657.2;
    test_Kd_x = 3.2; 
    test_Kd_y = 2.7; 
    test_Kd_z = 6.3;
    
    % Initialise DPID system
    dpid_init_robotic_sorting;
    
    % Measure performance
    metrics_dpid = measure_performance('dpid_robotic_sorting_system', stop_time, 'DPID (Discrete Waypoints)');
    
    % Save results
    save('performance_dpid.mat', 'metrics_dpid');
    fprintf('DPID results saved to performance_dpid.mat\n');
else
    fprintf('Loading existing DPID results...\n');
    load('performance_dpid.mat', 'metrics_dpid');
end

%% Test 2: Trajectory Smoothing System
if run_traj
    fprintf('\n=== TEST 2: TRAJECTORY SMOOTHING SYSTEM ===\n');
    fprintf('Running trajectory smoothing with Bayesian-optimised parameters...\n\n');
    
    % Clear workspace but preserve configuration
    clearvars -except stop_time run_dpid run_traj metrics_dpid
    
    % Set Bayesian-optimised parameters
    test_damping_x = 149.0; 
    test_damping_y = 115.1; 
    test_damping_z = 85.1;
    test_Kp_x = 361.0; 
    test_Kp_y = 311.7; 
    test_Kp_z = 433.0;
    test_Ki_x = 156.8; 
    test_Ki_y = 154.0; 
    test_Ki_z = 256.1;
    test_Kd_x = 24.4; 
    test_Kd_y = 25.4; 
    test_Kd_z = 30.2;
    
    % Initialise trajectory smoothing system
    init_robotic_sorting;
    
    % Measure performance
    metrics_traj = measure_performance('robotic_sorting_system', stop_time, 'Trajectory Smoothing (Optimised)');
    
    % Save results
    save('performance_traj.mat', 'metrics_traj');
    fprintf('Trajectory smoothing results saved to performance_traj.mat\n');
else
    fprintf('Loading existing trajectory smoothing results...\n');
    load('performance_traj.mat', 'metrics_traj');
end

%% Comparison Analysis
fprintf('\n========================================\n');
fprintf('COMPARATIVE ANALYSIS\n');
fprintf('========================================\n\n');

% Calculate improvements
improvement_mean_error = ((metrics_dpid.mean_error - metrics_traj.mean_error) / metrics_dpid.mean_error) * 100;
improvement_rms_error = ((metrics_dpid.rms_error - metrics_traj.rms_error) / metrics_dpid.rms_error) * 100;
improvement_max_error = ((metrics_dpid.max_error - metrics_traj.max_error) / metrics_dpid.max_error) * 100;
improvement_success = metrics_traj.success_rate - metrics_dpid.success_rate;
improvement_time = ((metrics_dpid.cycle_time - metrics_traj.cycle_time) / metrics_dpid.cycle_time) * 100;

% Create comparison table
fprintf('ACCURACY METRICS:\n');
fprintf('%-25s %15s %15s %15s\n', 'Metric', 'DPID', 'Traj Smooth', 'Improvement');
fprintf('%-25s %15s %15s %15s\n', repmat('-', 1, 25), repmat('-', 1, 15), repmat('-', 1, 15), repmat('-', 1, 15));
fprintf('%-25s %12.2f mm %12.2f mm %12.1f%%\n', 'Mean Error', metrics_dpid.mean_error, metrics_traj.mean_error, improvement_mean_error);
fprintf('%-25s %12.2f mm %12.2f mm %12.1f%%\n', 'RMS Error', metrics_dpid.rms_error, metrics_traj.rms_error, improvement_rms_error);
fprintf('%-25s %12.2f mm %12.2f mm %12.1f%%\n', 'Max Error', metrics_dpid.max_error, metrics_traj.max_error, improvement_max_error);
fprintf('%-25s %12.2f mm %12.2f mm %15s\n', 'Std Dev', metrics_dpid.std_error, metrics_traj.std_error, '-');
fprintf('%-25s %12.2f mm %12.2f mm %15s\n', '95th Percentile', metrics_dpid.error_95th, metrics_traj.error_95th, '-');
fprintf('%-25s %12.2f mm %12.2f mm %15s\n\n', '99th Percentile', metrics_dpid.error_99th, metrics_traj.error_99th, '-');

fprintf('PERFORMANCE METRICS:\n');
fprintf('%-25s %15s %15s %15s\n', 'Metric', 'DPID', 'Traj Smooth', 'Change');
fprintf('%-25s %15s %15s %15s\n', repmat('-', 1, 25), repmat('-', 1, 15), repmat('-', 1, 15), repmat('-', 1, 15));
fprintf('%-25s %13.1f%% %13.1f%% %13.1f%%\n', 'Success Rate', metrics_dpid.success_rate, metrics_traj.success_rate, improvement_success);
fprintf('%-25s %12.1f sec %12.1f sec %12.1f%%\n', 'Cycle Time', metrics_dpid.cycle_time, metrics_traj.cycle_time, improvement_time);
fprintf('%-25s %12.2f s/d %12.2f s/d %15s\n', 'Time per Dish', metrics_dpid.time_per_dish, metrics_traj.time_per_dish, '-');
fprintf('%-25s %13d/64 %13d/64 %15s\n\n', 'Dishes Completed', metrics_dpid.dishes_completed, metrics_traj.dishes_completed, '-');

fprintf('KEY IMPROVEMENTS:\n');
fprintf('  - Mean error reduced by %.1f%% (%.1fmm → %.1fmm)\n', ...
    improvement_mean_error, metrics_dpid.mean_error, metrics_traj.mean_error);
fprintf('  - RMS error reduced by %.1f%% (%.1fmm → %.1fmm)\n', ...
    improvement_rms_error, metrics_dpid.rms_error, metrics_traj.rms_error);
fprintf('  - Max error reduced by %.1f%% (%.1fmm → %.1fmm)\n', ...
    improvement_max_error, metrics_dpid.max_error, metrics_traj.max_error);
if improvement_success > 0
    fprintf('  - Success rate improved by %.1f%% (%.1f%% → %.1f%%)\n', ...
        improvement_success, metrics_dpid.success_rate, metrics_traj.success_rate);
end

%% Visualisation
figure('Name', 'System Comparison', 'Position', [100, 100, 1400, 800]);

% Subplot 1: Error comparison
subplot(2,3,1);
categories = {'Mean', 'RMS', 'Max', '95th %ile', '99th %ile'};
dpid_errors = [metrics_dpid.mean_error, metrics_dpid.rms_error, metrics_dpid.max_error, ...
               metrics_dpid.error_95th, metrics_dpid.error_99th];
traj_errors = [metrics_traj.mean_error, metrics_traj.rms_error, metrics_traj.max_error, ...
               metrics_traj.error_95th, metrics_traj.error_99th];

x = 1:length(categories);
bar(x, [dpid_errors; traj_errors]', 'grouped');
set(gca, 'XTickLabel', categories);
ylabel('Error (mm)');
title('Error Metrics Comparison');
legend('DPID', 'Trajectory Smoothing', 'Location', 'best');
grid on;

% Subplot 2: Improvement percentages
subplot(2,3,2);
improvements = [improvement_mean_error, improvement_rms_error, improvement_max_error];
bar(improvements);
set(gca, 'XTickLabel', {'Mean', 'RMS', 'Max'});
ylabel('Improvement (%)');
title('Error Reduction');
grid on;
yline(0, 'r--');

% Subplot 3: Success rate
subplot(2,3,3);
bar([metrics_dpid.success_rate, metrics_traj.success_rate]);
set(gca, 'XTickLabel', {'DPID', 'Traj Smooth'});
ylabel('Success Rate (%)');
title('Success Rate Comparison');
ylim([0 105]);
grid on;

% Subplot 4: Parameter comparison - Damping
subplot(2,3,4);
dpid_damp = [metrics_dpid.params.damping_x, metrics_dpid.params.damping_y, metrics_dpid.params.damping_z];
traj_damp = [metrics_traj.params.damping_x, metrics_traj.params.damping_y, metrics_traj.params.damping_z];
bar([dpid_damp; traj_damp]', 'grouped');
set(gca, 'XTickLabel', {'X', 'Y', 'Z'});
ylabel('Damping (N·s/m)');
title('Damping Coefficients');
legend('DPID', 'Traj Smooth', 'Location', 'best');
grid on;

% Subplot 5: Parameter comparison - Kp
subplot(2,3,5);
dpid_kp = [metrics_dpid.params.Kp_x, metrics_dpid.params.Kp_y, metrics_dpid.params.Kp_z];
traj_kp = [metrics_traj.params.Kp_x, metrics_traj.params.Kp_y, metrics_traj.params.Kp_z];
bar([dpid_kp; traj_kp]', 'grouped');
set(gca, 'XTickLabel', {'X', 'Y', 'Z'});
ylabel('Kp');
title('Proportional Gains');
legend('DPID', 'Traj Smooth', 'Location', 'best');
grid on;

% Subplot 6: Parameter comparison - Ki
subplot(2,3,6);
dpid_ki = [metrics_dpid.params.Ki_x, metrics_dpid.params.Ki_y, metrics_dpid.params.Ki_z];
traj_ki = [metrics_traj.params.Ki_x, metrics_traj.params.Ki_y, metrics_traj.params.Ki_z];
bar([dpid_ki; traj_ki]', 'grouped');
set(gca, 'XTickLabel', {'X', 'Y', 'Z'});
ylabel('Ki');
title('Integral Gains');
legend('DPID', 'Traj Smooth', 'Location', 'best');
grid on;

%% Save comparison results
comparison = struct();
comparison.dpid = metrics_dpid;
comparison.traj = metrics_traj;
comparison.improvements.mean_error_pct = improvement_mean_error;
comparison.improvements.rms_error_pct = improvement_rms_error;
comparison.improvements.max_error_pct = improvement_max_error;
comparison.improvements.success_rate_pts = improvement_success;
comparison.timestamp = datetime('now');

save('system_comparison.mat', 'comparison');

fprintf('\n========================================\n');
fprintf('Comparison complete!\n');
fprintf('Results saved to: system_comparison.mat\n');
fprintf('Figure saved. Use saveas(gcf, ''comparison.png'') to export.\n');
fprintf('========================================\n');